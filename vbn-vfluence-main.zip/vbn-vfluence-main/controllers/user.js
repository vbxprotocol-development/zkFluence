let User = require('../models/User')
const mongoose = require("mongoose")

module.exports ={

    getAllUsers: async(req, res) =>{
        try{
            const users = await User.find({})
            res.json(users)
         }catch(err){
            console.error(err)
        }
    },

   updateActivity: async (req, res) => {
    const {id: _id} = req.params
    const activity = req.body.last_activity
    
    
    const updatedActivity =  await User.updateOne({_id},{last_activity: activity})
    res.json(updatedActivity)
 },

    updateBio: async (req, res) => {
        const {id: _id} = req.params
        const bio = req.body.bio
        
        const updatedActivity =  await User.updateOne({_id},{bio: bio})
        res.json(updatedActivity)
     },


}