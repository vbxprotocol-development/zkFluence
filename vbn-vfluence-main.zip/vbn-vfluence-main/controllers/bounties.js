let Bounty = require('../models/bounty');
const mongoose = require("mongoose")
const validUrl = require("valid-url");
const got = require('got');
const cloudinary = require("../middleware/cloudinary");
const metascraper = require('metascraper')([
  require('metascraper-title')(),
  require('metascraper-description')(),
  require('metascraper-image')(),
  require('metascraper-author')(),
  require('metascraper-date')(),
  require('metascraper-logo')(),
  require('metascraper-url')()
])
const today = new Date()
const formattedDate = today.toLocaleDateString('en-US', { month: '2-digit', day: '2-digit', year: 'numeric' })
module.exports ={
  
    getBounty: async(req, res) =>{
    try{
        const bounties = await Bounty.find({
            expirationDate: { $exists: true, $gt: formattedDate },
        })
        res.json(bounties)
    } catch(err){
        console.error(err)
        res.status(500).send("Internal Server Error")
    }
},


    getBountyByTags: async(req, res) =>{
        try{
            const bounty = await Bounty.find({tags: req.params.tags})
            res.json(bounty)
            console.log(bounty)
          }catch(err){
            console.error(err)
          }
    },

    getBountyByCreator: async(req, res) =>{
        try{
            const bounty = await Bounty.find({creator: req.params.creator});
            if(!bounty)return res.status(404).json({ msg: "Post not found" });
            res.json(bounty);
          } catch (err) {
            console.error(err.message);
        
            if (err.kind === "ObjectId")
              return res.status(404).json({ msg: "Post not found" });
        
            res.status(500).send("Server Error");
          }
    },

    getTargetedBounty: async(req, res)=>{
      try{
        const bounty = await Bounty.find({vFluencer: req.params.vFluencer});
        if(!bounty)return res.status(404).json({ msg: "Post not found" });
            res.json(bounty);
      }catch(err){
        console.error(err.message);
        if (err.kind === "ObjectId")
              return res.status(404).json({ msg: "Post not found" });
        
            res.status(500).send("Server Error");
      }
    },

    getBountyById: async(req, res)=>{
      
      try{
        const bounty = await Bounty.findById({_id: req.params._id});
        if(!bounty)return res.status(404).json({ msg: "Post not found" });
            res.json(bounty);
      }catch(err){
      console.error(err.message);
      if (err.kind === "ObjectId")
      return res.status(404).json({ msg: "Post not found" });

    res.status(500).send("Server Error");
      }
    },

    //Ill come back to this.
    // getRecentActivity: async(req, res) =>{
    //   const twoHoursAgo = new Date(Date.now() - 2 * 60 * 60 * 1000);
    //   const bountyID = req.params.id;
    //   try {
    //     const bounty = await Bounty.findById({_id: req.params.bountyID});
    //     const recentActivities = [];
    //     bounty.dates.forEach((date) => {
    //       if (date.date > twoHoursAgo && date.date < new Date()) {
    //         recentActivities.push({
    //           userName: bounty.creator,
    //           clicks: date.clicks,
    //           date: date.date,
    //         });
    //       }
    //     });
    //     console.log(recentActivities, bounty)
    //     return recentActivities;
    //   } catch (error) {
    //     console.log(error);
    //   }
    // },
    
  
    createBounty: async (req, res) =>{
      try{
      const result = await cloudinary.uploader.upload(req.body.image);
      const { originalUrl, title, description, creator, tags, bounty, vFluencer, target, expirationDate, image} = req.body;

      const item = new Bounty ({
        originalUrl, title, description, creator, tags, bounty, vFluencer, target, expirationDate, result, image
        
      })
      item.save()
      res.status(200).json(item);
      console.log(item)
      }
        catch(err) {
          res.status(400).send("unable to save to database");
          console.log(err)
        };
    },

    validateUrls: (req, res, next) => {
      const { url, baseUrl } = req.body;
      // const baseUrl = "http://localhost:4000"
      const baseUrlIsValid = validUrl.isUri(baseUrl);
      const originalUrlIsValid = validUrl.isUri(url);
      const bothUrlsAreValid = baseUrlIsValid && originalUrlIsValid;
      if (bothUrlsAreValid) {
        console.log('These are Valid')
        next();
        return;
      } else if (!baseUrlIsValid) {
        return res.status(400).json("Invalid Base Url");
      } else if (!originalUrlIsValid) {
        return res.status(400).json("Invalid Original Url");
      }
    },

    linkScraper: (req, res, next) => {
      const targetUrl = req.body.url;
      (async () => {
        const { body: html, url } = await got(targetUrl);
        const metadata = await metascraper({ html, url });
        console.log(metadata)
        const { title, description, image, author,} = metadata;
        req.body.title = title;
        req.body.description = description;
        req.body.author = author;
        req.body.originalUrl = url;
        req.body.image = image;
        res.json(metadata)
      })()
    },

    //DEMO Related Function
    // updateBountyCounterById: async (req, res) => {
    //   try {
    //     const bounty = await Bounty.findById(req.params.id);
    
    //     if (!bounty) {
    //       return res.status(404).json({ msg: "Bounty not found" });
    //     }
    
    //     bounty.counter = 6501;
    //     await bounty.save();
    
    //     res.json(bounty);
    //   } catch (err) {
    //     console.error(err.message);
    
    //     if (err.kind === "ObjectId") {
    //       return res.status(404).json({ msg: "Bounty not found" });
    //     }
    
    //     res.status(500).send("Server Error");
    //   }
    // }
}