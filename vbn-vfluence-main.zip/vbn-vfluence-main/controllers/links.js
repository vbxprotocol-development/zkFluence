const mongoose = require("mongoose");
let Link = require('../models/link')
const shortid = require("shortid");
const validUrl = require("valid-url");
const got = require('got');
const bounty = require("../models/bounty");
const metascraper = require('metascraper')([
  require('metascraper-title')(),
  require('metascraper-description')(),
  require('metascraper-image')(),
  require('metascraper-author')(),
  require('metascraper-date')(),
  require('metascraper-logo')(),
  require('metascraper-url')()
])
const NodeCache = require("node-cache");
const cache = new NodeCache();

module.exports ={

generateLink: async (req, res) => {
    try {
      const { url, title, description, author, target, bounty, expirationDate, creator, baseUrl, counter, bountyId, image, creatorImg, creatorDisplayName } = req.body;
      const urlCode = shortid.generate();
      const shortUrl = "https://vfluence-alpha-theta.vercel.app/link/" + urlCode;
      const updatedAt = new Date();
      const item = new Link({
        url,
        urlCode,
        shortUrl,
        title,
        description,
        author,
        updatedAt,
        creator,
        baseUrl,
        counter,
        bountyId,
        image,
        creatorImg,
        creatorDisplayName,
        target,
        bounty,
        expirationDate
      });
  
      await item.save();
      res.status(200).json(item);
      console.log(item)
    }
    catch (e) {
      res.status(401).json("Invalid User Id");
    }
  },


  getLinkByBountyId: async(req, res)=>{ 
    try{
      const bounty = await Link.find({bountyId: req.params.bountyid});
      if(!bounty)return res.status(404).json({ msg: "Post not found" });
          res.json(bounty);
    }catch(err){
    console.error(err.message);
    if (err.kind === "ObjectId")
    return res.status(404).json({ msg: "Post not found" });

  res.status(500).send("Server Error");
    }
  },

  getLinkById: async(req, res)=>{ 
    try{
      const link = await Link.findById({_id: req.params.id});
      if(!link)return res.status(404).json({ msg: "Post not found" });
          res.json(link);
    }catch(err){
    console.error(err.message);
    if (err.kind === "ObjectId")
    return res.status(404).json({ msg: "Post not found" });

  res.status(500).send("Server Error");
    }
  },

  // getLinkByCode: async (req, res) => {
  //   const urlCode = req.params.code;
  //   Link.findOneAndUpdate({ urlCode: urlCode }, {$inc: {counter: 1}}, {new:true})
  //   .then((data) =>{
  //     bounty.findByIdAndUpdate({_id: data.bountyId}, {$inc: {counter: 1}}, {new:true})
  //     .then((data)=>{
  //       console.log(data.counter)
  //     })
  //     console.log(data.counter)})
  //   .catch((e)=>{console.log(e)})
    
  //   const item = await Link.findOne({ urlCode: urlCode });
  //   if (item) {
  //     //furiouscinnabun
  //     return res.redirect(item.url);
      
  //   } else {
  //     return res.status(404).json("Invalid link."); 
  //   }
  // },

getLinkByCode: async (req, res) => {
    const urlCode = req.params.code;
    Link.findOne({urlCode: urlCode}, (error, link) =>{
      bounty.findById(link.bountyId, (error, bountys) =>{
      const currentDate = new Date();
      const expirationDate = new Date(link.expirationDate);         
      if (expirationDate <= currentDate || bountys.counter >= link.target) {
        link.disabled = true;
        link.save((error) => {
          if (error) {
            console.log(error);
            return res.send('An error occurred while processing your request.');
          }
          return res.send('This link has been completed and is no longer accessible.');
        });
      }
      else {
        Link.findOneAndUpdate({ urlCode: urlCode }, {$inc: {counter: 1}}, {new:true})
          .then((data) =>{
            const today = new Date();
            bounty.findOneAndUpdate({_id: data.bountyId}, {$inc: {counter: 1}}, {new:true}, (error, bounty) => {
              if(error){
                console.log(error);
              }else{
                const currentObject = bounty.dates.find((item)=>item.date.toDateString()===today.toDateString());
                if(currentObject){
                  currentObject.clicks += 1;
                }else{
                  bounty.dates.push({
                    date: today,
                    clicks: 1,
                  })
                }
                bounty.save((error)=>{
                  if(error){
                    console.log(error)
                  }else{
                    console.log('Updated Bounty Counter')
                  }
                })
              }
            });
            console.log(data.counter);
            
            const currentObject = link.dates.find((item)=>item.date.toDateString()===today.toDateString());
            if(currentObject){
              currentObject.clicks += 1;
            }else{
              link.dates.push({
                date: today,
                clicks: 1,
              })
            }
            link.save((error)=>{
              if(error){
                console.log(error)
              }else{
                console.log('Updated Link Counter')
              }
            })
            return res.redirect(link.url);
          })
          .catch((e)=>{console.log(e)})
      }
    })
  })
},

getRecentActivity: async (req, res) => {
    const twoHoursAgo = new Date(Date.now() - 2 * 60 * 60 * 1000);
    const  bountyID  = req.params.bountyID;
    let recentActivities = cache.get(bountyID);
    // if (recentActivities) {
    //   return res.status(200).json({ recentActivities });
    // }
    try {
      const links = await Link.find({ bountyId: req.params.bountyID });
      recentActivities = [];
      links.forEach((link) => {
        link.dates.forEach((date) => {
          if (date.date > twoHoursAgo && date.date < new Date()) {
            const timeSince = Math.floor(
              (new Date().getTime() - date.date.getTime()) / 1000
            );
            let timeSinceString = '';
            if (timeSince < 60) {
              timeSinceString = `${timeSince} seconds ago`;
            } else if (timeSince < 3600) {
              const minutes = Math.floor(timeSince / 60);
              timeSinceString = `${minutes} minutes ago`;
            } else if (timeSince < 86400) {
              const hours = Math.floor(timeSince / 3600);
              timeSinceString = `${hours} hours ago`;
            } else {
              const days = Math.floor(timeSince / 86400);
              timeSinceString = `${days} days ago`;
            }
            recentActivities.push({
              userName: link.creatorDisplayName,
              creator: link.creator,
              clicks: date.clicks,
              date: timeSinceString,
            });
          }
        });
      });
      cache.set(bountyID, recentActivities);
      return res.status(200).json({ recentActivities });
    } catch (error) {
      console.log(error);
      return res.status(500).json({ message: 'Server error' });
    }
},
  
getLinkByCreator: async (req, res) => {
  const fetchBounties = async (bountyIds) => {
    const requests = bountyIds.map(bountyId => {
        return bounty.findById(bountyId);
    });
    
    return await Promise.all(requests);
}
    const creator = req.params.creator;
    const links = await Link.find({ creator: creator });
    if (!links) {
        return res.status(404).json("This Promoter does not have any links");
    }
    const bountyIds = links.map(link => link.bountyId);
    const bounties = await fetchBounties(bountyIds);
    const data = links.map((link, index) => {
      const bounty = bounties[index];
      const totalClicks = bounty ? bounty.counter : 0;
        return {...link.toObject(), totalClicks};
    });
    res.json(data);
},

getTotalClicksPerDay: async (req, res) => {
  const userId = req.params.userId;
  const timeFrame = req.params.timeFrame;
  const now = new Date();

  let startDate;
  if (timeFrame === 'week') {
    startDate = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
  } else if (timeFrame === 'month') {
    startDate = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
  } else if(timeFrame === 'year'){
    startDate = new Date(now.getTime() - 356 * 24 * 60 * 60 * 1000)
  }else {
    startDate = new Date(0);
  }

  try {
    const results = await Link.aggregate([
      {
        $match: {
          creator: userId,
          "dates.date": { $gte: startDate, $lt: now },
        }
      },
      {
        $unwind: "$dates"
      },
      {
        $match: {
          "dates.date": { $gte: startDate, $lt: now },
        }
      },
      {
        $group: {
          _id: {
            $dateToString: {
              format: "%Y-%m-%d",
              date: "$dates.date"
            }
          },
          totalClicks: { $sum: "$dates.clicks" }
        }
      },
      {
        $sort: { _id: 1 }
      }
    ]);

    res.send(results);
  } catch (error) {
    res.status(500).send(error);
  }
},

getTotalClicksBasedOnBounty: async (req, res) => {
  const bountyId = req.params.id;
  Link.aggregate([
      {
          $match: { bountyId: bountyId }
      },
      {
          $unwind: "$dates"
      },
      {
          $group: {
              _id: "$dates.date",
              clicks: { $sum: "$dates.clicks" }
          }
      },
      {
          $project: {
              _id: { $dateToString: { format: "%Y-%m-%d", date: "$_id" } },
              totalClicks: "$clicks"
          }
      },
      
      {
          $group: {
              _id: "$_id",
              totalClicks: { $sum: "$totalClicks" }
          }
      },
      {
        $sort: {
          _id: 1
        }
      }
  ]).exec((error, result) => {
      if (error) {
          res.status(500).send(error);
      } else {
          res.send(result);
      }
  });
},

getClicksBasedOnLinkID: async(req, res) =>{

  Link.aggregate([
    {
      $match: { _id: mongoose.Types.ObjectId(req.params.id) }
    },
    {
        $unwind: "$dates"
    },
    {
        $group: {
            _id: "$dates.date",
            clicks: { $sum: "$dates.clicks" }
        }
    },
    {
        $project: {
            _id: { $dateToString: { format: "%Y-%m-%d", date: "$_id" } },
            totalClicks: "$clicks"
        }
    },
    
    {
        $group: {
            _id: "$_id",
            totalClicks: { $sum: "$totalClicks" }
        }
    },
    {
      $sort: {
        _id: 1
      }
    }
]).exec((error, result) => {
    if (error) {
        res.status(500).send(error);
    } else {
        res.send(result);
    }
});
},

getTodayAndYesterdayClicks: async (req, res) => {
  try {
    const today = new Date();
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);
    const todayDate = today.toISOString().split('T')[0];
    const yesterdayDate = yesterday.toISOString().split('T')[0];

    const links = await Link.find({ creatorDisplayName: req.params.creator }).select('dates -_id');
    let clicksToday = 0;
    let clicksYesterday = 0;

    links.forEach(link => {
        link.dates.forEach(date => {
            const dateStr = date.date.toISOString().split('T')[0];
            if (dateStr === todayDate) {
                clicksToday += date.clicks;
            } else if (dateStr === yesterdayDate) {
                clicksYesterday += date.clicks;
            }
        });
    });

    let percentage = 0;
    if (clicksYesterday !== 0) {
        percentage = ((clicksToday - clicksYesterday) / (clicksToday + clicksYesterday)) * 100;
    }else{
      percentage = (clicksToday - clicksYesterday) * 100
    }
console.log({ clicksToday, clicksYesterday, percentage })

    res.json({ clicksToday, clicksYesterday, percentage });
} catch (error) {
    console.error(error);
    throw error;
}
},

calculatePayout: async (req, res) => {
  const urlCode = req.params.code;
  Link.findOne({urlCode: urlCode}, async (error, link) => {
    bounty.findById(link.bountyId, (error, bounty) =>{
    if (error) {
      console.log(error);
      return res.send('An error occurred while processing your request.');
    }
    if (!link) {
      return res.send('Invalid link code.');
    }
    const currentDate = new Date();
    const expirationDate = new Date(link.expirationDate);
    try {
      if (expirationDate > currentDate) {
        return res.send('The conditions for payout have not been met.');
      }else{
      const totalClicks = bounty.counter;
      const myClicks = link.counter;
      const payout = (myClicks / totalClicks) * bounty.bounty;
      link.payout = payout;
      link.save((error) => {
        if (error) {
          console.log(error);
          return res.send('An error occurred while processing your request.');
        }
        return res.send(`Your payout is $${payout}.`);
      });
    }
    } catch (error) {
      console.log(error);
      return res.send('An error occurred while processing your request.');
    }
  });
});
},

calculateTotalPayouts: async (req, res) => {
  const creator = req.params.creator;

  // Get the date from two months ago and one month ago
  const twoMonthsAgo = new Date();
  twoMonthsAgo.setMonth(twoMonthsAgo.getMonth() - 3);
  const oneMonthAgo = new Date();
  oneMonthAgo.setMonth(oneMonthAgo.getMonth() - 2);

  try {
    // Find all disabled links created by the user within the last month
    const disabledLinks = await Link.find({
      creator: creator,
      disabled: true,
      createdAt: { $gte: oneMonthAgo }
    });

    // Find all disabled links created by the user between two months ago and one month ago
    const disabledLinksPriorMonth = await Link.find({
      creator: creator,
      disabled: true,
      createdAt: { $gte: twoMonthsAgo, $lt: oneMonthAgo }
    });

    // Calculate the total payout for disabled links created in the last month
    const totalPayouts = disabledLinks.reduce((accumulator, link) => accumulator + link.payout, 0);

    // Calculate the total clicks generated across all disabled links created in the last month
    const totalClicks = disabledLinks.reduce((accumulator, link) => accumulator + link.counter, 0);

    // Calculate the average earnings per click for disabled links created in the last month
    const avgEarningsPerClick = totalPayouts / totalClicks;

    // Calculate the total payout for the user based on disabled links created in the last month
    const totalUserPayout = (totalPayouts) * 0.2;

    // Calculate the total payout for disabled links created in the prior month
    const totalPayoutsPriorMonth = disabledLinksPriorMonth.reduce((accumulator, link) => accumulator + link.payout, 0);

    // Calculate the total clicks generated across all disabled links created in the prior month
    const totalClicksPriorMonth = disabledLinksPriorMonth.reduce((accumulator, link) => accumulator + link.counter, 0);

    // Calculate the average earnings per click for disabled links created in the prior month
    const avgEarningsPerClickPriorMonth = (totalPayoutsPriorMonth / totalClicksPriorMonth > 0 ? totalPayoutsPriorMonth / totalClicksPriorMonth : 0);

    // Calculate the total payout for the user based on disabled links created in the prior month
    const totalUserPayoutPriorMonth = (totalPayoutsPriorMonth) * 0.2;

    return res.json({
      avgEarningsPerClick,
      totalUserPayout,
      avgEarningsPerClickPriorMonth,
      totalUserPayoutPriorMonth
    });
  } catch (error) {
    console.error(error);
    return res.status(500).send('Server error');
  }
},

//DEMO Related Function
// updateBountyCounterById: async (req, res) => {
//   try {
//     const link = await Link.findById('63fcd215df1abb054ded1da9');

//     if (!bounty) {
//       return res.status(404).json({ msg: "Bounty not found" });
//     }

//     link.dates.push({date: "2023-02-20T01:59:37.485+00:00", clicks: 375},

//     {date: "2023-02-21T01:59:37.485+00:00", clicks: 325},
    
//     {date: "2023-02-22T01:59:37.485+00:00", clicks: 463},
    
//     {date: "2023-02-23T01:59:37.485+00:00", clicks: 581},
    
//     {date: "2023-02-24T01:59:37.485+00:00", clicks: 785},
    
//     {date: "2023-02-25T01:59:37.485+00:00", clicks: 862},
    
//     {date: "2023-02-26T01:59:37.485+00:00", clicks: 772},
    
//     {date: "2023-02-27T01:59:37.485+00:00", clicks: 823});
//     await link.save();

//     res.json(link);
//   } catch (err) {
//     console.error(err.message);

//     if (err.kind === "ObjectId") {
//       return res.status(404).json({ msg: "Bounty not found" });
//     }

//     res.status(500).send("Server Error");
//   }
// }


}