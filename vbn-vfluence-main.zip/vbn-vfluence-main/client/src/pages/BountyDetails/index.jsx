import React, { useContext } from 'react';
import UserProvider from '../../contexts/UserProvider';
import styled from 'styled-components';
import UnauthenticatedUser from '../../components/UnauthenticatedUser';
import Bounty from '../../contexts/Bounty';

import AllUsers from '../../contexts/AllUsers';
import BountyDetails from './bounty';

const StyledDashboard = styled.div`
  width: 100%;
  margin: 0 auto;

  .pageTitle {
    font-weight: 400;
    font-size: 35px;
  }
`;

const BountyDetailsEnterance = (props) => {
    const userData = useContext(UserProvider.Context);
    const usersData = useContext(AllUsers.Context)
    return (
        <StyledDashboard>
            {userData ? (
                <>
                    <BountyDetails user={userData} users={usersData} />

                </>
            ) : (
                <UnauthenticatedUser />
            )}
        </StyledDashboard>
    );
};

export default BountyDetailsEnterance
    ;
