import React, { useEffect } from 'react'
import { useState, createContext, useContext } from 'react';
import NavBar from '../../components/NavBar';
import Axios from 'axios';
import api from '../../api'
import { useLocation } from 'react-router-dom'
import moment from 'moment';
import UserProvider from '../../contexts/UserProvider';
import './bounty.css'
import { CircleProgress } from 'react-gradient-progress'
import vbxIcon from '../../assets/images/yellowVBX.svg'
import arrowIcon from '../../assets/images/arrowIcon.svg'
import arrow from '../../assets/images/arrows.svg'
import copyIcon from '../../assets/images/copy.svg'
import arrowDown from '../../assets/images/arrowDown.svg'
import questionMark from '../../assets/images/questionMark.svg'
import ChatApp from '../../components/Comments/CommentsApp';
import arrowUp from '../../assets/images/arrowUp.svg'

const Context = createContext('');

const BountyDetails = ({ users }) => {
    const [bountyDetails, setBountyDetails] = useState([])
    const [currentPromoLink, setCurrentPromoLink] = useState()
    const [popup, setPopup] = useState(false)

    const [promoters, setPromoters] = useState([])
    const [sort, setSort] = useState(true)

    const location = useLocation()
    const { id } = location.state

    const currentDate = moment().format('YYYY-MM-DD')

    const user = useContext(UserProvider.Context);

    const togglePopUp = () => { setPopup(!popup); copyURL() }


    function copyURL() {
        if (!navigator.clipboard) {
            fallbackCopyURL()
            return
        }
        navigator.clipboard.writeText(currentPromoLink).then(function () {
            console.log('Copying is complete')
        }, function (err) {
            console.error('Copying failed', err)
        })
    }

    function fallbackCopyURL() {
        var input = document.createElement('input')
        input.setAttribute('value', currentPromoLink)
        document.body.appendChild(input)
        input.focus()
        input.select()
        try {
            document.execCommand('copy')
        } catch (e) {
            console.log(e)
        }
        document.body.removeChild(input)
    }

    const percentage = Math.floor(bountyDetails.counter / bountyDetails.target * 100)

    const fullBountyDetails = async (e) => {
        try {
            await api
            Axios.get(`/bounty/ID/${id}`)
                .then(res => {
                    setBountyDetails(res.data)
                    console.log(res.data)
                })
        } catch (e) {
            console.log(e)
        }

        try {
            await api
            Axios.get(`/link/promoter/${user.firstName}`)
                .then(res => {
                    res.data.forEach((element) => {
                        if (id == element.bountyId) {
                            setCurrentPromoLink(element.shortUrl)
                            console.log(currentPromoLink)
                        }
                        else {
                            console.log('This doesnt work')
                        }
                    })
                })
        } catch (e) {
            console.log(e)
        }
    }

    const promo = async (e) => {
        togglePopUp()
        if (!currentPromoLink) {
            const post = {
                baseUrl: "https://vfluence-alpha-theta.vercel.app/link/",
                creator: user.firstName,
                creatorImg: user.image,
                creatorDisplayName: user.displayName,
                counter: 0,
                bountyId: bountyDetails._id,
                title: bountyDetails.title,
                description: bountyDetails.description,
                author: bountyDetails.creator,
                url: bountyDetails.originalUrl,
                image: bountyDetails.image,
                expirationDate: bountyDetails.expirationDate,
                target: bountyDetails.target,
                bounty: bountyDetails.bounty,
                dates: [{
                    date: new Date(),
                    clicks: 0
                }]
            }
            try {
                await api
                Axios.post('/link/', post)
                    .then(res => {
                        console.log(res)
                        setCurrentPromoLink(res.data.shortUrl)
                    })

            } catch (e) {
                alert(e)
            }
        } else {
            return { currentPromoLink }
        }
    }

    let arr = []
    const topPromoters = async (e) => {
        try {
            await api
            Axios.get(`/link/bountyID/${id}`)
                .then(res => {
                    setPromoters(res.data.filter((ele, ind) => ind === res.data.findIndex(elem => elem.creator === ele.creator)).sort((a, b) => a.counter > b.counter ? -1 : 1))
                })

        } catch (e) {
            console.log(e)
        }
    }

    const rankedPromoters = promoters.map((promoter, index) => ({
        ...promoter,
        rank: index + 1,
    }));

    useEffect(() => {
        fullBountyDetails()
        const scrollToTop = () => {
            window.scrollTo(0, 0)
        }
        scrollToTop()
        topPromoters()
    }, []);

    //DEMO Related Call
    // const handleUpdateBountyCounter = async () => {
    //     try {
    //         const res = await Axios.put(`/bounty/bounty/${id}`);
    //         console.log(res.data);
    //     } catch (err) {
    //         console.error(err.message);
    //     }
    // };

    return (
        <>
            <NavBar />

            <div>
                <div className='background'></div>
                <div className='card' >
                    <div className='imageSection'>
                        <img src={bountyDetails.image} className='image' /></div>
                    <div className='section1'>
                        <div className='subsection1'>
                            <div className='spanCreator'>@{bountyDetails.creator}</div>
                            <div className='title'>{bountyDetails.title}</div>
                            <div className='description'>Description: <br />{bountyDetails.description}</div>

                        </div>

                        <div className='subsection2'>

                            <CircleProgress percentage={percentage >= 0 ? percentage : 0} primaryColor={['#F6CA2B', '#F68E43', '#FF1A1A']} strokeWidth={16} secondaryColor={'rgba(234, 236, 240, 1)'} fontFamily={'Inter'} fontSize={'24px'} width={228} />
                            {/* <button onClick={handleUpdateBountyCounter}>Update Counter</button> */}
                            <div className='clicksSubSection'>Clicks: {bountyDetails.counter > 0 ? bountyDetails.counter : 0}</div>
                        </div>
                    </div>

                    {/* <div>{bountyDetails.tags}</div>
                    <div>Days left until expiration: {moment(bountyDetails.expirationDate).diff(currentDate, 'days')}
                    </div>
                    <div>Expiration Date: {bountyDetails.expirationDate}</div> */}

                    <div className='section3'>

                        <div className='tvSection'>
                            <div className='topVfluencersTitle'>Top Vfluencers</div>
                            <div className='topVfluencers' >
                                <div className='legend'>
                                    <div className='legendName'>Name</div>
                                    <div className='legendClicks' onClick={() => { setSort(!sort) }}>Clicks <img src={sort ? arrowDown : arrowUp} /></div>
                                    <div className='legendWallet'>Wallet <img src={questionMark} /></div>
                                </div>
                                {sort ?
                                    rankedPromoters.sort((a, b) => a.counter > b.counter ? -1 : 1).map((promoter, index) => {
                                        return (<div className='topPromotersSection'>
                                            <div className='creatorSection'>
                                                <div className='rank'>#{promoter.rank}</div>
                                                <div className='tpImageSection'>
                                                    <img src={promoter.creatorImg} className='tpImage' />
                                                </div>

                                                <div className='tpNames'>
                                                    <div className='tpDisplayName'>{promoter.creatorDisplayName}</div>
                                                    <div className='tpFirstName'>@{promoter.creator}</div>
                                                </div>
                                            </div>
                                            <div className='tpCounter'>
                                                {promoter.counter}
                                            </div>

                                            <div className='tpWallet'>0x47c5...1411</div>
                                        </div>
                                        )

                                    }) :
                                    rankedPromoters.sort((a, b) => a.counter > b.counter ? 1 : -1).map((promoter, index) => {
                                        return (<div className='topPromotersSection'>
                                            <div className='creatorSection'>
                                                <div className='rank'>#{promoter.rank}</div>
                                                <div className='tpImageSection'><img src={promoter.creatorImg} className='tpImage' /></div>

                                                <div className='tpNames'>
                                                    <div className='tpDisplayName'>{promoter.creatorDisplayName}</div>
                                                    <div className='tpFirstName'>@{promoter.creator}</div>
                                                </div>
                                            </div>
                                            <div className='tpCounter'>
                                                {promoter.counter > 0 ? promoter.counter : 0}
                                            </div>

                                            <div className='tpWallet'>0x47c5...1411</div>
                                        </div>)
                                    })
                                }
                            </div>
                        </div>

                        <div className='comments'>
                            <div className='commentsTitle'>Comments</div>
                            <ChatApp username={user.displayName} id={id} profilePic={user.image} className='chatApp' />
                        </div>


                    </div>


                    <div className='footer'>
                        <div className='footerSection1'>
                            <div className='bountyAmount'>BOUNTY
                                <div className='innerBountySection'>
                                    <img src={vbxIcon} />
                                    <div className='bountyOptions'>
                                        <div>{bountyDetails.bounty} VBX</div>
                                        <div>${bountyDetails.bounty * 0.2}</div>
                                    </div>
                                </div>
                            </div>

                        </div><div className='footerSection2'>
                            <div className='targetClicks'>TARGET <div>{bountyDetails.target}</div></div>
                            <div className='generatedClicks'>CLICKS <div>{bountyDetails.counter > 0 ? bountyDetails.counter : 0 && console.log(bountyDetails.counter)}</div></div>
                            <div className='expirationDateFooter'>EXPIRATION DATE <div>{bountyDetails.expirationDate}</div></div>
                            <div className='size'>$ PER CLICK <div>${((bountyDetails.counter / bountyDetails.bounty) * 0.2) > 0 ? ((bountyDetails.counter / bountyDetails.bounty) * 0.2).toFixed(2) : 0}</div></div>
                            <img src={arrowIcon} onClick={promo} />
                        </div>
                    </div>

                </div>
            </div>

            {popup && (
                <div className="Popup">
                    <div onClick={togglePopUp} className="overlay"></div>
                    <div className="Popup-content">
                        <div>
                            <img src={arrow} /></div>


                        <div className='popupMessage'>Personalized link coped to clipboard! <br /> <div>Share link anywhere and earn based on clicks generated</div></div>
                        <div className='URL'>Personalized URL: {currentPromoLink}<img src={copyIcon} onClick={copyURL} />
                        </div></div>
                </div>

            )}

        </>
    )
}


BountyDetails.Context = Context

export default BountyDetails