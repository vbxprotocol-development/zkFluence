import React, { useContext } from 'react';
import UserProvider from '../../contexts/UserProvider';
import styled from 'styled-components';
import UnauthenticatedUser from '../../components/UnauthenticatedUser';
import Wallet from './wallet';


const StyledDashboard = styled.div`
  
  margin: 0 auto;
  text-align: center;

  .pageTitle {
    font-weight: 400;
    font-size: 35px;
  }
`;

const WalletEnterance = () => {
    const userData = useContext(UserProvider.Context);
    return (
        <StyledDashboard>
            {userData ? (
                <Wallet user={userData} />
            ) : (
                <UnauthenticatedUser />
            )}
        </StyledDashboard>
    );
};

export default WalletEnterance;
