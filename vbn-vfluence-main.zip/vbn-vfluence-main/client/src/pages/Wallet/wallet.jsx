import React, { useEffect, useState } from 'react'
import NavBar from '../../components/NavBar'
import api from '../../api'
import moment from 'moment'
import Axios from 'axios';
import './wallet.css'
import VBXIcon from '../../assets/images/yellowVBX.svg'
import { useWindowWidth } from '../../components/functions/useWindowWidth';

const Wallet = ({ user }) => {
    const windowWidth = useWindowWidth();

    useEffect(() => {
    }, []);

    return (
        <>
            <NavBar />
            <div className='walletBackground'>
            </div>
            <div className='totalSection'>
                <div className='walletTitle'>My Wallet</div>

                <div className='walletSection1'>
                    <div className='walletBalanceSection'>
                        <div className='walletBalance'>
                            <div>Current Balance:</div>
                            <div className='mainWalletBalance'>
                                <img src={VBXIcon} alt='VBX' />
                                <div className='innerMainWalletBalance'>
                                    <div className='vbxCurrent'>14548 VBX</div>
                                    <div className='dollarCurrent'>$2909.60</div>
                                </div>
                            </div>
                        </div>
                        <div className='walletBalanceHistorySection'>
                            <div className='vbxEarned'>
                                <div>VBX Earned</div>
                                <div>16809</div>
                            </div>
                            <div className='vbxReceived'>
                                <div>VBX Received</div>
                                <div>230</div>
                            </div>
                            <div className='vbxSpent'>
                                <div>VBX Spent</div>
                                <div>2491</div>
                            </div>
                        </div>

                    </div>
                    <div className='walletDivider'></div>
                    <div className='walletAddressSection'>
                        <div className='walletAddress'>
                            <div className=''>Wallet Address:</div>
                            <div className='actualAddress'>9da2a4a32d28da8f3a8a48bb694eb...</div>
                        </div>
                        <div className='walletAddressBtns'>
                            <button className='editAddress'>Edit Address</button>
                            <button className='copy' >Copy</button>
                        </div>
                    </div>
                </div>

                <div className='walletSection2'>
                    <div className='transactiontitle'>
                        <div className='transactionHistory'>Transaction History</div>
                        {windowWidth > 601 
                        ?
                        <div className='transactionBtns'>
                        <button className='vbxEarnedHistory'>VBX Earned</button>
                        <button className='vbxReceivedHistory'>VBX Received</button>
                        <button className='vbxSpentHistory'>VBX Spent</button>
                        </div> 
                        :
                         <select className='transactionSelector'>
                            <option>VBX Earned</option>
                            <option>VBX Received</option>
                            <option>VBX Spent</option>
                         </select>
                        }
                        
                    </div>

                    <div>
                        <div className='walletHistoryLegend'>
                            <div className='date'>Date</div>
                            <div className='paymentsReceived'>Payments Received</div>
                            <div className='bountyCreator'>Bounty Creator</div>
                            <div className='bountyAddress'>Bounty Address</div>
                            <div className='bountySize'>Bounty Size</div>
                            <div className='bountyInfo'>Bounty Info</div>
                        </div>

                        <table>
                            <tr>
                                <td>02/27/23</td>
                                <td>2,809 VBX</td>
                                <td>HBO</td>
                                <td>0x7D1AfA7B718fb893dB30A3aBc0Cfc608AaCfeBB0</td>
                                <td>4,500,000 VBX</td>
                                <td>View Link Info</td>
                            </tr>
                            <tr>
                                <td>02/27/23</td>
                                <td>363 VBX</td>
                                <td>NIKE</td>
                                <td>0x1f9840a85d5af5bf1d1762f925bdaddc4201f984</td>
                                <td>675,000 VBX</td>
                                <td>View Link Info</td>
                            </tr>
                            <tr>
                                <td>02/19/23</td>
                                <td>8,001 VBX</td>
                                <td>Karli Kloss</td>
                                <td>0x2260fac5e5542a773aa44fbcfedf7c193bc2c599</td>
                                <td>280,000 VBX</td>
                                <td>View Link Info</td>
                            </tr>
                            <tr>
                                <td>02/14/23</td>
                                <td>1,462 VBX</td>
                                <td>Andy Mint</td>
                                <td>0x514910771af9ca656af840dff83e8264ecf986ca</td>
                                <td>55,000 VBX</td>
                                <td>View Link Info</td>
                            </tr>
                            <tr>
                                <td>02/14/23</td>
                                <td>236 VBX</td>
                                <td>BAPE</td>
                                <td>0x5a98fcbea516cf06857215779fd812ca3bef1b32</td>
                                <td>360,000 VBX</td>
                                <td>View Link Info</td>
                            </tr>
                            <tr>
                                <td>02/10/23</td>
                                <td>2,038 VBX</td>
                                <td>DONDA</td>
                                <td>0xc944e90c64b2c07662a292be6244bdf05cda44a7</td>
                                <td>1,000,000 VBX</td>
                                <td>View Link Info</td>
                            </tr>
                            <tr>
                                <td>01/30/23</td>
                                <td>176 VBX</td>
                                <td>DONDA</td>
                                <td>0xc944e90c64b2c07662a292be6244bdf05cda44a7</td>
                                <td>1,000,000 VBX</td>
                                <td>View Link Info</td>
                            </tr>
                            <tr>
                                <td>01/29/23</td>
                                <td>1724 VBX</td>
                                <td>DONDA</td>
                                <td>0xc944e90c64b2c07662a292be6244bdf05cda44a7</td>
                                <td>2,000,000 VBX</td>
                                <td>View Link Info</td>
                            </tr>
                        </table>
                    </div>
                </div>


            </div>

        </>
    )
}

export default Wallet