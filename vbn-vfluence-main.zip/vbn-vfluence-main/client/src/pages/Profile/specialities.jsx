import React, { useEffect, useState } from 'react'
import './profile.css'
import xOut from '../../assets/images/xButton.svg'
import enterKey from '../../assets/images/enterKey.svg'

function Specialities({ maxTags, onAddTag }) {
    const [tags, setTags] = useState([]);
    const [tagInput, setTagInput] = useState('');

    const handleTagInputKeyDown = (e) => {
        if (e.key === 'Enter' && tagInput.trim() !== '') {
            e.preventDefault();
            if (tags.length < maxTags) {
                setTags([...tags, tagInput.trim()]);
                onAddTag([...tags, tagInput.trim()]);
                setTagInput('');
            }
        } else if (e.key === 'Backspace' && tagInput === '') {
            const newTags = [...tags];
            newTags.pop();
            setTags(newTags);
            onAddTag(newTags);
        }
    };

    const handleRemoveTag = (tagIndex) => {
        setTags(tags.filter((_, index) => index !== tagIndex));
        onAddTag(tags.filter((_, index) => index !== tagIndex));
    };

    return (
        <div className='specialitiesBackground'>
            <div style={{ flexGrow: '1', flexShrink: '1', display: 'flex', flexDirection: 'column', alignItems: 'flex-start', justifyContent: 'flex-start' }}>
                <div style={{ display: 'inline-flex', flexWrap: 'wrap' }}>
                    {tags.map((tag, index) => (
                        <div
                            key={index}
                            style={{
                                background: '#F8DF5B',
                                borderRadius: '100px',
                                display: 'flex',
                                alignItems: 'center',
                                margin: '4px',
                                marginBottom: '16px',
                                padding: '4px 6px 4px 10px',
                            }}
                        >
                            <span style={{ marginRight: '8px' }}>{tag}</span>
                            <img
                                onClick={() => handleRemoveTag(index)}
                                style={{
                                    backgroundColor: 'transparent',
                                    border: 'none',
                                    cursor: 'pointer',
                                }}
                                src={xOut}
                            />
                        </div>
                    ))}
                </div>
            </div><div className='profileDivider' style={{ height: '0', width: '100%', border: '1px solid #FFFFFF' }}></div>
            <div style={{ flexGrow: '0', flexShrink: '0', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
                <div style={{ position: 'relative', width: '360px', }}>
                    <input
                        type="text"
                        value={tagInput}
                        onKeyDown={handleTagInputKeyDown}
                        onChange={(e) => setTagInput(e.target.value)}
                        placeholder=""
                        style={{
                            display: tags.length >= maxTags ? 'none' : 'inline-block',
                            width: '100%',
                            height: '30px',
                            marginLeft: '5px',
                            padding: '0',
                            border: 'none',
                            backgroundColor: 'transparent',
                            color: 'white',
                        }}
                    />
                    <img src={enterKey} style={{
                        position: 'absolute',
                        top: '8px',
                        right: '10px'
                    }} />
                </div>
            </div>

        </div>

    );
}

export default Specialities