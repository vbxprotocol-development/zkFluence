import React, { useContext } from 'react';
import UserProvider from '../../contexts/UserProvider';
import styled from 'styled-components';
import UnauthenticatedUser from '../../components/UnauthenticatedUser';
import Profile from './profile'

const StyledDashboard = styled.div`
  
  margin: 0 auto;
  text-align: center;

  .pageTitle {
    font-weight: 400;
    font-size: 35px;
  }
`;

const ProfileEnterance = () => {
    const userData = useContext(UserProvider.Context);
    return (
        <StyledDashboard>
            {userData ? (
                <Profile user={userData} />
            ) : (
                <UnauthenticatedUser />
            )}
        </StyledDashboard>
    );
};

export default ProfileEnterance;
