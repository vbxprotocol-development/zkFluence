import React, { useEffect, useRef, useState } from 'react'
import NavBar from '../../components/NavBar'
import api from '../../api'
import moment from 'moment'
import Axios from 'axios';
import './profile.css'
import profileBackground from '../../assets/images/profileBackground.svg'
import createProfile from '../../assets/images/createProfile.svg'
import stepper from '../../assets/images/stepper.svg'
import stepper2 from '../../assets/images/stepper2.svg'
import stepper3 from '../../assets/images/stepper3.svg'
import defaultProfilePic from '../../assets/images/defaultProfilePic.svg'
import uploadProfilePic from '../../assets/images/uploadProfilePic.svg'
import next from '../../assets/images/nextIcon.svg'
import check from '../../assets/images/completedProfileCheck.svg'
import Specialities from './specialities';
import enterKey from '../../assets/images/enterKey.svg'
import xOut from '../../assets/images/xButton.svg'
import { Link } from 'react-router-dom';
const Profile = ({ user }) => {

    const [page1, setPage1] = useState(true)
    const [page2, setPage2] = useState(false)
    const [page3, setPage3] = useState(false)
    const [page4, setPage4] = useState(false)
    const [page5, setPage5] = useState(false)
    const [page6, setPage6] = useState(false)
    const [page7, setPage7] = useState(false)
    const [specialties, setSpecialties] = useState([]);

    const [profileImage, setProfileImage] = useState()
    const [name, setName] = useState('')
    const [shortBio, setShortBio] = useState('')
    const [audience, setAudience] = useState('')

    const [showInput, setShowInput] = useState(false);
    const [channels, setChannels] = useState(['Discord', 'Twitter', 'Groupchat', 'Facebook']);
    const [newChannelName, setNewChannelName] = useState('');
    const [showModal, setShowModal] = useState(false);
    const [selectedChannels, setSelectedChannels] = useState([]);
    const [tagInput, setTagInput] = useState('');

    const [myBounties, setMyBounties] = useState()
    const [id, setID] = useState()

    const handleTagInputKeyDown = (e) => {
        if (e.key === 'Enter' && tagInput.trim() !== '') {
            e.preventDefault();
            if (specialties.length < 10) {
                setSpecialties([...specialties, tagInput.trim()]);

                setTagInput('');
            }
        } else if (e.key === 'Backspace' && tagInput === '') {
            const newTags = [...specialties];
            newTags.pop();
            setSpecialties(newTags);

        }
    };

    const handleRemoveTag = (tagIndex) => {
        setSpecialties(specialties.filter((_, index) => index !== tagIndex));

    };

    const handleAddChannelClick = () => {
        setShowInput(true);
    };

    const handleNewChannelNameChange = (event) => {
        setNewChannelName(event.target.value);
    };

    const handleNewChannelNameSubmit = (event) => {
        event.preventDefault();
        const newChannel = newChannelName.trim();
        if (newChannel.length > 0) {
            setChannels([newChannel, ...channels]);
            setSelectedChannels([newChannel, ...selectedChannels]);
        }
        setNewChannelName('');
        setShowInput(false);
    };

    const handleChannelClick = (channel) => {
        if (selectedChannels.includes(channel)) {
            setSelectedChannels(selectedChannels.filter((c) => c !== channel));
        } else {
            setSelectedChannels([...selectedChannels, channel]);
        }
    };

    const handleModalOpen = () => {
        setShowModal(true);
        setPage4(!page4);
    };

    const handleModalClose = () => {
        setShowModal(false);
        setPage5(!page5);
    };

    const fileInputRef = useRef(null);

    const handlePage2 = () => {
        setPage1(!page1); setPage2(!page2)
    }

    const handlePage3 = () => {
        setPage2(!page2); setPage3(!page3)
    }

    const handlePage4 = () => {
        setPage3(!page3); setPage4(!page4)
    }

    const handlePage5 = () => {
        setPage4(!page4); setPage5(!page5)
    }

    const handlePage6 = () => {
        setPage5(!page5); setPage6(!page6)
    }

    const handleEditProfile = () => {
        setPage6(!page6); setPage7(!page7)
    }
    const handleSaveEdits = () => {
        setPage7(!page7); setPage6(!page6)
    }

    const handleUploadButtonClick = () => {
        fileInputRef.current.click();
    };

    const handleProfileImageUpload = (e) => {
        const file = e.target.files[0];
        TransformFileData(file);
    };

    const TransformFileData = (file) => {
        const reader = new FileReader();
        if (file) {
            reader.readAsDataURL(file);
            reader.onloadend = () => {
                setProfileImage(reader.result);
            };
        } else {
            setProfileImage("");
        }
    };

    let myArr = []
    const getMyBounties = async () => {
        try {
            await api
            Axios.get(`/bounty/yourBounty/${user.displayName}`)
                .then(res => {
                    res.data.forEach((bounties) => {
                        if (bounties.expirationDate !== undefined && moment().isBefore(bounties.expirationDate) && bounties.tags.length < 2 && bounties.tags != "")
                            myArr.push(bounties)
                    });
                    setMyBounties(myArr)
                })
        } catch (e) {
            console.log(e)
        }
    }

    useEffect(() => {
        getMyBounties()
    }, []);

    return (
        <div>
            <NavBar />
            {user.hasCustomProfile ? null
                :
                <div>
                    <div className='profileVector' ></div>

                    {page1 && (
                        <>
                            <div className='profileBackground'>
                                <div className='createYourProfileScreen'>
                                    <img src={createProfile} alt="" onClick={handlePage2} />
                                    <div className='createYourProfileTitle'>Create Your Profile</div>
                                    <div className='createYourProfileDesc'>Create your profile to have the full experience consectetur adipiscing<br /> elit. Praesent nec metus neque.</div>
                                    <button className='getStarted' onClick={handlePage2}>Get Started</button>
                                </div>
                            </div>
                        </>
                    )}

                    {page2 && (
                        <>
                            <div className='profileBackground'>
                                <div className='profileTitle'>Profile</div>
                                <img src={stepper} />

                                <div className='profilePicUploadSection'>
                                    <img src={profileImage || defaultProfilePic} />
                                    <div className='uploadBtnSection'>
                                        <div>Upload Profile Picture</div>
                                        <img src={uploadProfilePic} onClick={handleUploadButtonClick} />
                                        <input
                                            type='file'
                                            accept='image/*'
                                            ref={fileInputRef}
                                            onChange={handleProfileImageUpload}
                                            style={{ display: 'none' }}
                                        />

                                    </div>
                                </div>

                                <div>
                                    <form className='nameAndBio'>
                                        <label>Name</label>
                                        <input
                                            required={true}
                                            placeholder='Enter your name'
                                            className='enterName'
                                            onChange={(event) => { setName(event.target.value) }}
                                            value={name}
                                        />

                                        <label>Short Bio</label>
                                        <textarea
                                            required={true}
                                            placeholder="Enter your short bio"
                                            className='shortBio'
                                            onChange={(e) => { setShortBio(e.target.value) }}
                                            value={shortBio}
                                            align="top"
                                            wrap="soft"
                                        />
                                    </form>
                                </div>

                                <img src={next} onClick={handlePage3} className='profileNextBtn3' />
                            </div>
                        </>
                    )}

                    {page3 && (
                        <>
                            <div className='profileBackground'>
                                <div className='specialitiesTitle'>Specialities</div>
                                <img src={stepper2} className='stepper2' />

                                <div className='addSpecialitiesTitle'>
                                    <div>Add your Specialities</div>
                                    <div>(Up to 10 categories)</div>
                                </div>

                                <Specialities
                                    maxTags={10}
                                    onAddTag={(tags) => setSpecialties(tags)}
                                />
                                <img src={next} onClick={handlePage4} className='profileNextBtn4' />
                            </div>
                        </>
                    )}

                    {page4 && (
                        <>
                            <div className='profileBackground2'>
                                <div className='distributionTitle'>Distribution Methods</div>
                                <div className='skip' onClick={handlePage5}>Skip</div>
                                <img src={stepper3} />
                                <div className='question'>Where will you share your links?</div>

                                <div className='channels'>
                                    {showInput ? (
                                        <form onSubmit={handleNewChannelNameSubmit}>
                                            <input
                                                type='text'
                                                value={newChannelName}
                                                onChange={handleNewChannelNameChange}
                                                placeholder='Enter channel here'
                                                className='addChannelInput'
                                            />
                                            <img src={enterKey} alt='Enter' onClick={handleNewChannelNameSubmit} />
                                        </form>
                                    ) : (
                                        <div onClick={handleAddChannelClick}>+ Add Channel</div>
                                    )}
                                    {channels.map((channel) => (
                                        <div
                                            key={channel.toLowerCase()}
                                            className={channel.toLowerCase()}
                                            onClick={() => handleChannelClick(channel)}
                                            style={{ border: selectedChannels.includes(channel) ? '2px solid #FFD600' : 'none' }}
                                        >
                                            {channel}
                                        </div>
                                    ))}
                                </div>


                                <img src={next} onClick={handleModalOpen} className='profileNextBtn4' />
                            </div>
                        </>
                    )}

                    {showModal && (
                        <div className='profileBackground'>
                            <div className='distributionTitle'>Distribution Methods</div>
                            <img src={stepper3} />
                            <div className='question'>Write something about your audience</div>

                            <textarea className='audienceSection' type="text" onChange={(e) => { setAudience(e.target.value) }} value={audience} align="top"
                                wrap="soft" />
                            <img src={next} onClick={handleModalClose} className='profileNextBtn3' />
                        </div>
                    )}

                    {page5 && (
                        <>
                            <div className='profileBackground'>
                                <img src={check} className='checkMark' />
                                <div className='completedTitle'>Profile page created!</div>

                                <div className='completedDesc'>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent nec metus neque. Lorem ipsum dolor sit amet, consectetur adipiscing elit.</div>

                                <button onClick={handlePage6} className='continueBTN'>Continue</button>
                            </div>
                        </>
                    )}

                    {page6 && myBounties && (
                        <div className='profileBackground3'>
                            <div className='profileEndTitle'>Profile</div>
                            <div className='profileend'>
                                <img src={profileImage || defaultProfilePic} />

                                <div className='nameEnd'>
                                    <div className='nameEnd'>Name</div>
                                    <div>{name}</div>
                                </div>

                                <div className='shortBioEnd'>
                                    <div>Short Bio</div>
                                    <div>{shortBio}</div>
                                </div>

                                <div className='specialitiesEnd'>
                                    <div>Specialities</div>
                                    <div style={{ display: 'inline-flex', flexWrap: 'wrap', }}>
                                        {specialties.map((tag, index) => (
                                            <div
                                                key={index}
                                                style={{
                                                    background: '#F8DF5B',
                                                    borderRadius: '100px',
                                                    display: 'flex',
                                                    alignItems: 'center',
                                                    marginBottom: '16px',
                                                    marginRight: '8px',
                                                    padding: '4px 6px 4px 10px',
                                                    width: 'fit-content',
                                                    height: 'fit-content',
                                                    color: 'black'
                                                }}
                                            >
                                                <span style={{ marginRight: '8px' }}>{tag}</span>
                                                <img
                                                    onClick={() => handleRemoveTag(index)}
                                                    style={{
                                                        backgroundColor: 'transparent',
                                                        border: 'none',
                                                        cursor: 'pointer',

                                                    }}
                                                    src={xOut}
                                                />
                                            </div>
                                        ))}

                                    </div>
                                </div>

                                <div className={myBounties.length < 1 ? 'bountiesEnd' : 'myBountiesEnd'}>
                                    <div>List of recently created bounties</div>
                                    {myBounties.length < 1 ? (
                                        <div>No bounties created yet</div>
                                    ) : (
                                        <div>
                                            {myBounties
                                                .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)) // sort by createdAt in descending order
                                                .slice(0, 2) // take the first 2 bounties
                                                .map((bounty) => (
                                                    <div className='bountiesProfile'>
                                                        <div onMouseEnter={() => setID(bounty._id)}>
                                                            <Link to={{ pathname: "/bountyDetails", state: { id: id } }} className='bountyLinkProfile'>
                                                                <div>{bounty.title}</div>
                                                                <button>View Full Bounty Card</button>
                                                            </Link>
                                                        </div>
                                                    </div>
                                                ))}
                                        </div>
                                    )}
                                </div>

                                <div className='distributionChannelsEnd'>
                                    {selectedChannels.length >= 1
                                        ?
                                        <>
                                            <div>Distribution Channels</div>
                                            <div>
                                                {selectedChannels.length >= 1 ? selectedChannels.map((channels) => (
                                                    <div style={{
                                                        marginBottom: '16px', fontFamily: 'Work Sans',
                                                        fontStyle: 'normal',
                                                        fontWeight: '400',
                                                        fontSize: '18px',
                                                        lineHeight: '140%',
                                                    }}>{channels}</div>
                                                )) : null}
                                            </div></>
                                        :
                                        null
                                    }

                                </div>

                                {audience ?
                                    <div className='audienceEnd'>
                                        <div>My Audience</div>
                                        <div>{audience}</div>
                                    </div>
                                    : null}
                                <button onClick={handleEditProfile}>Edit Profile</button>
                            </div>
                        </div>
                    )}

                    {page7 && myBounties && (
                        <div className='profileBackground3'>
                            <div className='profileEndTitle'>Profile</div>
                            <div className='profileendEdit'>
                                <div className='editUploadedImage'>
                                    <img src={profileImage || defaultProfilePic} />
                                    <div className='uploadBtnSection'>
                                        <div>Upload Profile Picture</div>
                                        <img src={uploadProfilePic} onClick={handleUploadButtonClick} />
                                        <input
                                            type='file'
                                            accept='image/*'
                                            ref={fileInputRef}
                                            onChange={handleProfileImageUpload}
                                            style={{ display: 'none' }}
                                        />
                                    </div>
                                </div>
                                <div className='nameEnd'>
                                    <div className='nameEnd'>Name</div>
                                    <input
                                        required={true}
                                        placeholder='Enter your name'
                                        className='enterNameEdit'
                                        onChange={(event) => { setName(event.target.value) }}
                                        value={name}

                                    />
                                </div>

                                <div className='shortBioEnd'>
                                    <div>Short Bio</div>
                                    <textarea
                                        required={true}
                                        placeholder="Enter your short bio"
                                        className='shortBioEdit'
                                        onChange={(e) => { setShortBio(e.target.value) }}
                                        value={shortBio}
                                        wrap="soft"
                                        align="top"
                                    />
                                </div>

                                <div className='specialitiesEnd'>
                                    <div>Specialities</div>
                                    <div style={{ display: 'inline-flex', flexWrap: 'wrap', alignItems: 'center', background: 'rgba(255, 255, 255, 0.04)', width: '602px', height: '112px', paddingLeft: '20px', marginBottom: '24px' }} className='specialitiesEdit'>
                                        {specialties.map((tag, index) => (
                                            <div
                                                key={index}
                                                style={{
                                                    background: '#F8DF5B',
                                                    borderRadius: '100px',
                                                    display: 'flex',
                                                    alignItems: 'center',
                                                    marginBottom: '16px',
                                                    marginRight: '8px',
                                                    padding: '4px 6px 4px 10px',
                                                    width: 'fit-content',
                                                    height: 'fit-content',
                                                    color: 'black'
                                                }}
                                            >
                                                <span style={{ marginRight: '8px' }}>{tag}</span>
                                                <img
                                                    onClick={() => handleRemoveTag(index)}
                                                    style={{
                                                        backgroundColor: 'transparent',
                                                        border: 'none',
                                                        cursor: 'pointer',
                                                    }}
                                                    src={xOut}
                                                />

                                            </div>
                                        ))}
                                        <input
                                            type="text"
                                            value={tagInput}
                                            onKeyDown={handleTagInputKeyDown}
                                            onChange={(e) => setTagInput(e.target.value)}
                                            placeholder=""
                                            style={{
                                                display: specialties.length >= 10 ? 'none' : 'inline-block',
                                                width: '360px',
                                                height: '30px',
                                                padding: '0',
                                                border: 'none',
                                                backgroundColor: 'transparent',
                                                color: 'white',
                                            }}
                                        />
                                    </div>
                                </div>

                                <div className={myBounties.length < 1 ? 'bountiesEnd' : 'myBountiesEnd'}>
                                    <div>List of recently created bounties</div>
                                    {myBounties.length < 1 ? (
                                        <div>No bounties created yet</div>
                                    ) : (
                                        <div>
                                            {myBounties
                                                .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)) // sort by createdAt in descending order
                                                .slice(0, 2) // take the first 2 bounties
                                                .map((bounty) => (
                                                    <div className='bountiesProfile'>
                                                        <div onMouseEnter={() => setID(bounty._id)}>
                                                            <Link to={{ pathname: "/bountyDetails", state: { id: id } }} className='bountyLinkProfile'>
                                                                <div>{bounty.title}</div>
                                                                <button>View Full Bounty Card</button>
                                                            </Link>
                                                        </div>
                                                    </div>
                                                ))}
                                        </div>
                                    )}
                                </div>

                                <div className='distributionChannelsEnd'>
                                    <div>Distribution Channels</div>
                                    <div className='channelsEdit'>
                                        {showInput ? (
                                            <form onSubmit={handleNewChannelNameSubmit}>
                                                <input
                                                    type='text'
                                                    value={newChannelName}
                                                    onChange={handleNewChannelNameChange}
                                                    placeholder='Enter channel here'
                                                    className='addChannelInput'
                                                />
                                                <img src={enterKey} alt='Enter' onClick={handleNewChannelNameSubmit} />
                                            </form>
                                        ) : (
                                            <div onClick={handleAddChannelClick}>+ Add Channel</div>
                                        )}</div>
                                    {selectedChannels.length >= 1 ? selectedChannels.map((channels) => (
                                        <div style={{
                                            marginBottom: '16px', fontFamily: 'Work Sans',
                                            fontStyle: 'normal',
                                            fontWeight: '400',
                                            fontSize: '18px',
                                            lineHeight: '140%',
                                        }}>{channels}</div>
                                    )) : null}
                                </div>


                                <div className='audienceEnd'>
                                    <div>My Audience</div>
                                    <textarea className='audienceSectionEdit' type="text" onChange={(e) => { setAudience(e.target.value) }} value={audience} align="top"
                                        wrap="soft" />
                                </div>

                                <button onClick={handleSaveEdits}>Save</button>
                            </div>
                        </div>
                    )}
                </div>

            }
        </div>
    )
}

export default Profile