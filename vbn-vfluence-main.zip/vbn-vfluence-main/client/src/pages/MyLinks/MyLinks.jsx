import React, { useEffect, useRef } from 'react'
import { useState, createContext } from 'react';
import NavBar from '../../components/NavBar';
import Axios from 'axios';
import api from '../../api'
import moment from 'moment'
import { Link } from 'react-router-dom';
import './myLinks.css'
import "react-step-progress-bar/styles.css";
import { ProgressBar } from "react-step-progress-bar";
import arrowIcon from '../../assets/images/arrowIcon.svg'
import { Line } from 'react-chartjs-2';
import { CircleProgress } from 'react-gradient-progress'
import vbxIcon from '../../assets/images/yellowVBX.svg'
import threeDots from '../../assets/images/threeDots.svg'
import greenGraph from '../../assets/images/greenGraph.svg'
import redGraph from '../../assets/images/redGraph.svg'
import redArrow from '../../assets/images/redArrow.svg'
import greenArrow from '../../assets/images/greenArrow.svg'
import arrowDown from '../../assets/images/arrowDown.svg'
import arrowUp from '../../assets/images/arrowUp.svg'
import closeOut from '../../assets/images/closeOut.svg'
import viewBounty from '../../assets/images/viewBounty.svg'
import arrow from '../../assets/images/arrows.svg'
import copyIcon from '../../assets/images/copy.svg'

const MyLinks = ({ user }) => {
    const [chartData, setChartData] = useState({});
    const [myLinksData, setMyLinksData] = useState([])
    const [LinkID, setLinkID] = useState('')
    const currentDate = moment().format('YYYY-MM-DD')
    const [mainPage, setMainPage] = useState(true)
    const [fullLinkView, setFullLinkView] = useState(false)
    const [linksData, setLinksData] = useState()
    const [linkURL, setLinkURL] = useState()
    const [id, setID] = useState()
    const [linkDataGraph, setLinkDataGraph] = useState()
    const [bountyDataGraph, setBountyDataGraph] = useState()
    const [selectedOption, setSelectedOption] = useState('all');
    const [showLinks, setShowLinks] = useState('all');
    const [allLinks, setAllLinks] = useState('showAllLinks')
    const [completeLinks, setcompleteLinks] = useState('completeLink')
    const [incompleteLinks, setincompleteLinks] = useState('incompleteLink')
    const [recentActivity, setRecentActivity] = useState([])
    const [sort, setSort] = useState(true)
    const [clickComparisonData, setClickComparisonData] = useState()
    const [monthsRevenue, setMonthsRevenue] = useState()
    const [lastMonthsRevenue, setLastMonthsRevenue] = useState()
    const [avgEarningsPerClick, setAvgEarningsPerClick] = useState()
    const [avgEarningsPerClickLastMonth, setAvgEarningsPerClickLastMonth] = useState()
    const [popup, setPopup] = useState(false)
    const [URLCode, setURLCode] = useState()

    const handleButtonClick = (type) => {
        setShowLinks(type);
        if (type == 'all') {
            setAllLinks('showAllLinks')
            setcompleteLinks('completeLink')
            setincompleteLinks('incompleteLink')
        } else if (type == 'complete') {
            setAllLinks('allLink')
            setcompleteLinks('showCompleteLinks')
            setincompleteLinks('incompleteLink')
        } else {
            setAllLinks('allLink')
            setcompleteLinks('completeLink')
            setincompleteLinks('showIncompleteLinks')
        }
    }

    const filteredLinks = myLinksData.filter((link) => {
        if (showLinks === 'all') {
            return true;
        } else if (showLinks === 'complete') {
            return moment(link.expirationDate).isBefore(currentDate);
        } else {
            return moment(link.expirationDate).isAfter(currentDate);
        }
    });

    const handleModals = () => {
        setFullLinkView(!fullLinkView);
        window.scrollTo(0, 200);
    }

    const getLinkData = async () => {
        try {
            await api
            Axios.get(`/link/linkID/${LinkID}`)
                .then(res => {
                    setLinksData(res.data)
                    setLinkURL(res.data.shortUrl)
                    setID(res.data.bountyId)

                })
        } catch (e) {
            console.log(e)
        }

    }

    const getMyLinks = async () => {
        try {
            await api
            Axios.get(`/link/promoter/${user.firstName}`)
                .then(res => {
                    setMyLinksData(res.data)
                })
        } catch (e) {
            console.log(e)
        }
    }

    const togglePopUp = () => { setPopup(!popup); copyURL() }


    function copyURL() {
        if (!navigator.clipboard) {
            fallbackCopyURL()
            return
        }
        navigator.clipboard.writeText(linkURL).then(function () {
            console.log('Copying is complete')
        }, function (err) {
            console.error('Copying failed', err)
        })
    }

    function fallbackCopyURL() {
        var input = document.createElement('input')
        input.setAttribute('value', linkURL)
        document.body.appendChild(input)
        input.focus()
        input.select()
        try {
            document.execCommand('copy')
        } catch (e) {
            console.log(e)
        }
        document.body.removeChild(input)
    }

    function fallbackCopyURL() {
        var input = document.createElement('input')
        input.setAttribute('value', linkURL)
        document.body.appendChild(input)
        input.focus()
        input.select()
        try {
            document.execCommand('copy')
        } catch (e) {
            console.log(e)
        }
        document.body.removeChild(input)
    }

    const getLinkGraphData = async () => {
        try {
            await api
            Axios.get(`/link/clicks/${LinkID}`)
                .then(res => {
                    setLinkDataGraph(res.data)
                    console.log(res.data)
                })
        } catch (e) {
            console.log(e)
        }
    }

    const getBountyGraphData = async () => {
        try {
            await api
            Axios.get(`/link/clicksBounty/${id}`)
                .then(res => {
                    console.log({ id })
                    console.log(res.data)
                    console.log(res)
                    setBountyDataGraph(res.data)

                })
        } catch (e) {
            console.log(e)
        }
    }

    const getRecentActivity = async () => {
        try {
            await api
            Axios.get(`/link/recent-activities/${id}`)
                .then(res => {
                    setRecentActivity(res.data.recentActivities)

                })
        } catch (e) {
            console.log(e)
        }
    }
    const [response, setResponse] = useState()
    const getPayout = async () => {
        try {
            await api
            Axios.get(`/link/payout/${URLCode}`)
                .then(res => {
                    console.log(res)
                    setResponse(res)

                })
        } catch (e) {
            console.log(e)
        }
    }

    let avgEarningsArr = []
    let revenueArr = []
    const [avgEarningsArray, setAvgEarningsArray] = useState()
    const [revenueArray, setRevenueArray] = useState()
    const getPayoutData = async () => {
        try {
            await api
            Axios.get(`/link/totalPayouts/${user.firstName}`)
                .then(res => {
                    setAvgEarningsPerClickLastMonth(res.data.avgEarningsPerClickPriorMonth)
                    setAvgEarningsPerClick(res.data.avgEarningsPerClick)
                    setLastMonthsRevenue(res.data.totalUserPayoutPriorMonth)
                    setMonthsRevenue(res.data.totalUserPayout)

                    avgEarningsArr.push(res.data.avgEarningsPerClickPriorMonth)
                    avgEarningsArr.push(Math.round(res.data.avgEarningsPerClick))
                    setAvgEarningsArray(avgEarningsArr)

                    revenueArr.push(res.data.totalUserPayoutPriorMonth)
                    revenueArr.push(res.data.totalUserPayout)
                    setRevenueArray(revenueArr)

                })
        } catch (e) {
            console.log(e)
        }
    }

    let arr = []
    const [array, setArray] = useState()
    const [percentage, setPercentage] = useState()
    const getClickComparisonData = async () => {
        try {
            await api
            Axios.get(`/link/clicks-summary/${user.displayName}`)
                .then(res => {
                    setClickComparisonData(res.data)
                    setPercentage(res.data.percentage)
                    console.log(res.data.percentage)
                    arr.push(res.data.clicksYesterday)
                    arr.push(res.data.clicksToday)
                    setArray(arr)
                })
        } catch (e) {
            console.log(e)
        }
    }

    const getBackgroundColor = (percentage) => {
        return percentage < 0 ? 'rgba(255, 0, 0, 0.1)' : 'rgba(0, 255, 0, 0.1)';
    };

    const getBorderColor = (percentage) => {
        return percentage < 0 ? 'rgba(255, 0, 0, 1)' : 'rgba(0, 255, 0, 1)';
    };
    const getBackgroundColor2 = (percentage) => {
        return percentage < 0 ? 'rgba(255, 0, 0, 0.1)' : 'rgba(0, 255, 0, 0.1)';
    };

    const getBorderColor2 = (percentage) => {
        return percentage < 0 ? 'rgba(255, 0, 0, 1)' : 'rgba(0, 255, 0, 1)';
    };
    const getBackgroundColor3 = (percentage) => {
        return percentage < 0 ? 'rgba(255, 0, 0, 0.1)' : 'rgba(0, 255, 0, 0.1)';
    };

    const getBorderColor3 = (percentage) => {
        return percentage < 0 ? 'rgba(255, 0, 0, 1)' : 'rgba(0, 255, 0, 1)';
    };

    const fullBountyDetails = async () => {
        try {
            await api
            Axios.get(`/link/promoter/${user.firstName}`)
                .then(res => {

                    if (res.data.filter((ele) => ele.bountyId.includes(id.toString())).length >= 1) {
                        console.log(res.data)
                        res.data.forEach((element) => {
                            if (id == element.bountyId) {
                                setLinkURL(element.shortUrl)
                                togglePopUp()
                                return { linkURL }
                            }
                        })
                        console.log('stage')
                    } else {
                        return null
                    }
                })

        } catch (e) {
            console.log(e)
        }

    }

    useEffect(() => {
        getMyLinks()
        getClickComparisonData()
        getPayoutData()
    }, [])

    useEffect(() => {
        Axios.get(`/link/clicks/${user.firstName}/${selectedOption}`)
            .then(res => {
                const clicks = res.data.map(item => item.totalClicks);
                const dates = res.data.map(item => item._id);
                const formattedDates = res.data.map(item => moment(item._id).format("MMMM DD"))
                setChartData({
                    labels: formattedDates,
                    datasets: [
                        {
                            data: clicks,
                            backgroundColor: 'rgba(75,192,192,0.4)',
                            borderColor: '#FFFFFF',
                            borderWidth: 0,
                            pointBackgroundColor: "white",
                            pointRadius: 1.5,
                            pointHoverRadius: 8,
                            fill: false,
                            lineTension: 0,

                        }
                    ]
                })
            })
            .catch(err => console.log(err))
    }, [selectedOption])


    const [yearPoints, setYearPoints] = useState('yearBtn')
    const [weekPoints, setWeekPoints] = useState('weekBtn')
    const [monthPoints, setMonthPoints] = useState('monthBtn')
    const [allPoints, setAllPoints] = useState('allBtnSelected')

    const handleOptionSelection = (option) => {
        setSelectedOption(option);
        if (option == 'all') {
            setAllPoints('allBtnSelected')
            setYearPoints('yearBtn')
            setWeekPoints('weekBtn')
            setMonthPoints('monthBtn')
        } else if (option == 'year') {
            setYearPoints('yearBtnSelected')
            setMonthPoints('monthBtn')
            setWeekPoints('weekBtn')
            setAllPoints('allBtn')
        } else if (option == 'week') {
            setWeekPoints('weekBtnSelected')
            setMonthPoints('monthBtn')
            setYearPoints('yearBtn')
            setAllPoints('allBtn')
        } else if (option == 'month') {
            setMonthPoints('monthBtnSelected')
            setWeekPoints('weekBtn')
            setYearPoints('yearBtn')
            setAllPoints('allBtn')
        }
    }

    //DEMO Related Call
    // const handleUpdateBountyCounter = async () => {
    //     try {
    //         const res = await Axios.put(`/link/bounty/${LinkID}`);
    //         console.log(res.data);
    //     } catch (err) {
    //         console.error(err.message);
    //     }
    // };

    return (
        <div className='myLinks'>
            {mainPage && clickComparisonData && (
                <>
                    <NavBar />
                    <div className='linkPageBackground'>
                    </div>
                    <div className='graphSection'>
                        <div className='upperSec'>
                            <div className='upperGraphSecTitle'>Your active and inactive links, performance and activity</div>
                            <div className='boxes'>
                                <div className='box1'>
                                    <div className='innerTitle'>
                                        <div>This month's revenue</div>
                                        <img src={threeDots} />
                                    </div>

                                    <div className='innerBottom'>
                                        <div className='innerNumbers'>
                                            <div>${monthsRevenue}</div>
                                            <span>
                                                {monthsRevenue / (monthsRevenue + lastMonthsRevenue) > 0 ?
                                                    <div className='percentSection'>
                                                        <img src={greenArrow} />
                                                        <div className='greenPercent'>{monthsRevenue / (monthsRevenue + lastMonthsRevenue)}%</div>
                                                        last month
                                                    </div>
                                                    :
                                                    <div className='percentSection'>
                                                        <img src={redArrow} />
                                                        <div className='redPercent'>{monthsRevenue / (monthsRevenue + lastMonthsRevenue)}%</div>
                                                        last month
                                                    </div>}
                                            </span>
                                        </div>
                                        <div className='clicksGraph1'>
                                            <Line data={{
                                                labels: ['Last Month', 'This Month'],
                                                datasets: [
                                                    {
                                                        data: revenueArray,
                                                        backgroundColor: getBackgroundColor(monthsRevenue / (monthsRevenue + lastMonthsRevenue)),
                                                        borderColor: getBorderColor(monthsRevenue / (monthsRevenue + lastMonthsRevenue)),
                                                        borderWidth: 2,
                                                        pointBackgroundColor: "white",
                                                        pointRadius: 3,
                                                        pointHoverRadius: 8,
                                                        fill: true,
                                                        lineTension: 0,
                                                    }
                                                ]
                                            }}
                                                options={{
                                                    title: {
                                                        display: false,
                                                    },
                                                    legend: {

                                                        display: false,

                                                    },
                                                    scales: {
                                                        yAxes: [{
                                                            display: false
                                                        }],
                                                        xAxes: [{
                                                            display: false
                                                        }]

                                                    },
                                                }}

                                            />
                                        </div>

                                    </div>
                                </div>

                                <div className='box2'>
                                    <div className='innerTitle'>
                                        <div>Today's Clicks</div>
                                        <img src={threeDots} />
                                    </div>

                                    <div className='innerBottom'>
                                        <div className='innerNumbers'>
                                            <div>{clickComparisonData.clicksToday}</div>
                                            <span>{percentage < 0 ?
                                                <div className='percentSection'>
                                                    <img src={redArrow} />
                                                    <div className='redPercent'>
                                                        {Math.round(percentage)}%
                                                    </div>yesterday
                                                </div>
                                                : percentage === 0 ? <div className='percentSection'>

                                                    <div className='redPercent'>
                                                        {Math.round(percentage)}%
                                                    </div>yesterday
                                                </div>
                                                    :
                                                    <div className='percentSection'>
                                                        <img src={greenArrow} />
                                                        <div className='greenPercent'>
                                                            {Math.round(percentage)}%
                                                        </div>yesterday
                                                    </div>
                                            }</span>
                                        </div>
                                        <div className='clicksGraph'>
                                            <Line data={{
                                                labels: ['Yesterday', 'Today'],
                                                datasets: [
                                                    {
                                                        data: array,
                                                        backgroundColor: getBackgroundColor3(percentage),
                                                        borderColor: getBorderColor3(percentage),
                                                        borderWidth: 2,
                                                        pointBackgroundColor: "white",
                                                        pointRadius: 3,
                                                        pointHoverRadius: 8,
                                                        fill: true,
                                                        lineTension: 0,
                                                    }
                                                ]
                                            }}
                                                options={{
                                                    title: {
                                                        display: false,
                                                    },
                                                    legend: {

                                                        display: false,

                                                    },
                                                    scales: {
                                                        yAxes: [{
                                                            display: false
                                                        }],
                                                        xAxes: [{
                                                            display: false
                                                        }]

                                                    },
                                                }}

                                            />
                                        </div>
                                    </div>
                                </div>

                                <div className='box3'>
                                    <div className='innerTitle'>
                                        <div>Avg. Earnings Per Click</div>
                                        <img src={threeDots} />
                                    </div>

                                    <div className='innerBottom'>
                                        <div className='innerNumbers'>
                                            <div>${Math.round(avgEarningsPerClick)}</div>
                                            <span>
                                                {avgEarningsPerClick / (avgEarningsPerClick + avgEarningsPerClickLastMonth) > 0 ?
                                                    <div className='percentSection'>
                                                        <img src={greenArrow} />
                                                        <div className='greenPercent'>{avgEarningsPerClick / (avgEarningsPerClick + avgEarningsPerClickLastMonth)}% </div>
                                                        last month
                                                    </div>
                                                    :
                                                    <div className='percentSection'>
                                                        <img src={redArrow} />
                                                        <div className='redPercent'>{avgEarningsPerClick / (avgEarningsPerClick + avgEarningsPerClickLastMonth)}% </div>
                                                        last month
                                                    </div>}
                                            </span>
                                        </div>
                                        <div className='clicksGraph2'>
                                            <Line data={{
                                                labels: ['Last Month', 'This Month'],
                                                datasets: [
                                                    {
                                                        data: avgEarningsArray,
                                                        backgroundColor: getBackgroundColor2(avgEarningsPerClick / (avgEarningsPerClick + avgEarningsPerClickLastMonth)),
                                                        borderColor: getBorderColor2(avgEarningsPerClick / (avgEarningsPerClick + avgEarningsPerClickLastMonth)),
                                                        borderWidth: 2,
                                                        pointBackgroundColor: "white",
                                                        pointRadius: 3,
                                                        pointHoverRadius: 8,
                                                        fill: true,
                                                        lineTension: 0,
                                                    }
                                                ]
                                            }}
                                                options={{
                                                    title: {
                                                        display: false,
                                                    },
                                                    legend: {

                                                        display: false,

                                                    },
                                                    scales: {
                                                        yAxes: [{
                                                            display: false
                                                        }],
                                                        xAxes: [{
                                                            display: false
                                                        }]

                                                    },
                                                }}

                                            />
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className='filterBtnSection'>
                        <div className='filterButtons'>
                            <button onClick={() => handleOptionSelection('all')} className={allPoints}>All Time</button>
                            <button onClick={() => handleOptionSelection('year')} className={yearPoints}>Last Year</button>
                            <button onClick={() => handleOptionSelection('month')} className={monthPoints}>Last Month</button>
                            <button onClick={() => handleOptionSelection('week')} className={weekPoints}>Last Week</button>
                        </div>
                        </div>
                        <div className='lineBar'>
                            <div>
                                <div className='dot'></div>
                                <div className='legendTitle'>Total Clicks</div>
                            </div>
                            <Line
                                data={chartData}
                                options={{
                                    title: {
                                        display: false,
                                    },
                                    legend: {

                                        display: false,

                                    },
                                    scales: {
                                        yAxes: [{
                                            display: false
                                        }],

                                    },
                                }}
                                width={1018}
                                height={216}

                            /></div>
                    </div>
                    <div>
                         
                        <div className='sortSection'>
                            <div className='sortLinksBtn'>
                                <button onClick={() => handleButtonClick('all')} className={allLinks}>All</button>
                                <button onClick={() => handleButtonClick('complete')} className={completeLinks}>Completed</button>
                                <button onClick={() => handleButtonClick('incomplete')} className={incompleteLinks}>Incomplete</button>
                            </div>
                            <div>Showing Last 50 Bounties</div>
                        </div>
                         
                        <div className='linksSection'>
                            {filteredLinks.sort((a, b) => {
                                const aExpired = moment(a.expirationDate).isBefore(currentDate);
                                const bExpired = moment(b.expirationDate).isBefore(currentDate);
                                if (aExpired && !bExpired) {
                                    return 1;
                                } else if (!aExpired && bExpired) {
                                    return -1;
                                } else {
                                    return moment(a.expirationDate).diff(b.expirationDate, 'days');
                                }
                            }).map(links =>
                                <div className='myLinksLink'>

                                    <div className='MyLinkCard' onMouseEnter={() => { setLinkID(links._id); setID(links.bountyId); setURLCode(links.urlCode) }} onClick={() => { getLinkData(); handleModals(); getBountyGraphData(); getLinkGraphData(); getRecentActivity(); getPayout() }}>
                                        <div className='linkImageSection'>
                                            <img src={links.image} className={links.image ? 'linkImage' : 'linkImageBroken'} />


                                            <div className='linkSection1'>
                                                <div>
                                                    <div className='linkTitle'>{links.title.length > 60 ? links.title.slice(0, 60) + '...' : links.title}</div>
                                                    <img src={arrowIcon} className='linkArrowIcon' onClick={(e) => { e.stopPropagation(); fullBountyDetails(); }} />
                                                </div>
                                                <div className='linkCounter'>{links.counter} Clicks</div>

                                                <div className="progressBarer">
                                                    <ProgressBar
                                                        percent={(links.counter / links.target) * 100}
                                                        filledBackground='linear-gradient(to right, #F6DF71, #FFD701)'
                                                        unfilledBackground='rgba(255, 255, 255, 0.2)'
                                                        width='258px'

                                                    /></div>
                                                <div className='indicator'>{links.totalClicks}/{links.target} Clicks</div>
                                            </div>


                                        </div>
                                    </div>
                                    <div className={moment(links.expirationDate).isBefore(currentDate) ? 'linkExpired' : 'linkExpiration'}>
                                        <div>
                                            {moment(links.expirationDate).isBefore(currentDate) ? 'Expired!' :
                                                moment(links.expirationDate).diff(currentDate, 'days') >= 7 ?
                                                    Math.floor(moment(links.expirationDate).diff(currentDate, 'days') / 7) + ' Weeks Remaining' :
                                                    moment(links.expirationDate).diff(currentDate, 'days') + ' Days Remaining'
                                            }
                                        </div>

                                    </div>

                                </div>
                            )}
                        </div>
                    </div>
                </>
            )}
            <div>
                {fullLinkView && linksData && linkDataGraph && bountyDataGraph && recentActivity && response && (
                    <div className='linkCardBackground overlay'>
                        <div className='linkCardSection'>
                            <div className='linkCardTopSection'>
                                <Link to={{ pathname: "/bountyDetails", state: { id: id } }} className="linkToBounty"><img src={viewBounty} /></Link>
                                <img src={closeOut} onClick={handleModals} />
                            </div>
                            <div className='linkCardImageSection'>
                                <div className='spanCreatorLinkCard'>@{linksData.creatorDisplayName}</div>
                                <img src={linksData.image} />

                            </div>

                            <div className='linkCardSecondSection'>
                                <div className='linkCardInnerSection'>
                                    <div className='linkCardTitleSection'>
                                        <div className='linkCardTitle'>{linksData.title}</div>
                                        <div className='linkCardDesc'>Description: <br />{linksData.description}</div>

                                    </div>

                                    <div className='linksubsection2'>

                                        <CircleProgress percentage={Math.floor(linksData.counter / linksData.target * 100)
                                            >= 0 ? Math.floor(linksData.counter / linksData.target * 100) : 0} primaryColor={['#F6CA2B', '#F68E43', '#FF1A1A']} strokeWidth={16} secondaryColor={'rgba(234, 236, 240, 1)'} fontFamily={'Inter'} fontSize={'24px'} width={228} />
                                        <div className='linkclicksSubSection'>Clicks: {linksData.counter > 0 ? linksData.counter : 0}</div>
                                        {/* <button onClick={handleUpdateBountyCounter}>Update Counter</button> */}
                                    </div>
                                </div>
                                <div className='dividerLinkCard'></div>



                                <div className='linkCardInnerBottomSection'>

                                    <div className='recentActivityLinkCard'>
                                        <div className='raSection'>
                                            <div className='recentActivityTitle'>Recent Activity</div>
                                            <div className='recentActivity' >
                                                <div className='legend2'>
                                                    <div className='legendName2'><div>Name</div></div>
                                                    <div className='legendClicks2'><div>Activity</div></div>
                                                    <div className='legendWallet2'><div>Wallet</div></div>
                                                    <div className='legendTime2' onClick={() => { setSort(!sort) }}><div>Time<img src={sort ? arrowDown : arrowUp} /></div> </div>
                                                </div>
                                                {sort ?
                                                    recentActivity.sort((a, b) => a.date > b.date ? 1 : -1).map((recents) => {
                                                        return (<div className='raNameSection'>
                                                            <div className='recentActivityNamesSection'>
                                                                <div className='raNames'>
                                                                    <div className='raDisplayName'>{recents.userName}</div>
                                                                    <div className='raFirstName'>@{recents.creator ? recents.creator : "Placeholder"}</div>
                                                                </div>
                                                            </div>
                                                            <div className='raCounter'>
                                                                <div>{recents.clicks} Clicks</div>
                                                            </div>

                                                            <div className='raWallet'><div>0x47c5...1411</div></div>
                                                            <div className='raDate'><div>{recents.date}</div></div>
                                                        </div>
                                                        )

                                                    }) :
                                                    recentActivity.sort((a, b) => a.date > b.date ? -1 : 1).map((recents) => {
                                                        return (<div className='raNameSection'>
                                                            <div className='recentActivityNamesSection'>
                                                                <div className='raNames'>
                                                                    <div className='raDisplayName'>{recents.userName}</div>
                                                                    <div className='raFirstName'>@{recents.creator ? recents.creator : "Placeholder"}</div>
                                                                </div>
                                                            </div>
                                                            <div className='raCounter'>
                                                                {recents.clicks > 0 ? recents.clicks : 0} Clicks
                                                            </div>

                                                            <div className='raWallet'><div>0x47c5...1411</div></div>
                                                            <div className='raDate'><div>{recents.date}</div></div>
                                                        </div>)
                                                    })
                                                }
                                            </div>
                                        </div>
                                    </div>
                                    <div className='linkCardGraphParentSection'>
                                    <div className='linkCardGraphSection'>
                                        <Line
                                            data={{
                                                labels: [...new Set(bountyDataGraph.map(item => item._id).concat(linkDataGraph.map(item => item._id)))].sort(),
                                                datasets: [
                                                    {
                                                        label: 'My Clicks',
                                                        data: [...new Set(bountyDataGraph.map(item => item._id).concat(linkDataGraph.map(item => item._id)))].sort().map(date => linkDataGraph.find(item => item._id === date)?.totalClicks || 0),
                                                        borderColor: '#FFFFFF',
                                                    },
                                                    {
                                                        label: 'Total Clicks',
                                                        data: [...new Set(bountyDataGraph.map(item => item._id).concat(linkDataGraph.map(item => item._id)))].sort().map(date => bountyDataGraph.find(item => item._id === date)?.totalClicks || 0),
                                                        borderColor: '#6172F3',
                                                    }
                                                ]
                                            }}
                                            options={{
                                                title: {
                                                    display: false,

                                                },
                                                legend: {
                                                    display: false
                                                },
                                                scales: {
                                                    xAxes: [{
                                                        type: 'time',
                                                        time: {
                                                            unit: 'day',
                                                            displayFormats: {
                                                                day: 'MMM DD'
                                                            },
                                                            tooltipFormat: 'MMM DD',
                                                            parser: (label) => moment(label, 'YYYY-MM-DD').valueOf()
                                                        },

                                                    }],
                                                    yAxes: [{
                                                        display: false
                                                    }]
                                                }
                                            }}
                                            width={465}
                                            height={207}

                                        />
                                    </div>
                                    </div>
                                </div>

                                <div className='dividerLinkCard2'></div>

                                <div className='linkCardFooter'>
                                    <div className='linkBounty'>
                                        <div>
                                            <div>BOUNTY</div>
                                            <div className='innerLinkBountySection'>
                                                <img src={vbxIcon} />
                                                <div className='bountyLinkOptions'>
                                                    <div>50{linksData.bounty} VBX</div>
                                                    <div>$2,200</div>
                                                </div>
                                            </div>
                                        </div>
                                        <div className='linkTarget'>TARGET <div>{linksData.target}</div></div>
                                        <div className='linkClicksCard'>CLICKS <div>{linksData.counter > 0 ? linksData.counter : 0}</div></div>
                                    </div>

                                    <img src={arrowIcon} className='copyArrowLinkCard' onClick={togglePopUp} />


                                </div>


                            </div>
                        </div>
                    </div>


                )}</div>
            {popup && (
                <div className="Popup">
                    <div onClick={togglePopUp} className="overlay"></div>
                    <div className="Popup-content">
                        <div>
                            <img src={arrow} /></div>
                        <div className='popupMessage'>Personalized link coped to clipboard! Share link anywhere <br />and earn based on clicks generated</div>
                        <div className='URL'>Personalized URL: {linkURL}<img src={copyIcon} onClick={copyURL} />
                        </div></div>
                </div>

            )}
        </div >


    )
}


export default MyLinks