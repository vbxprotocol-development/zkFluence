import React, { useContext } from 'react';
import UserProvider from '../../contexts/UserProvider';
import styled from 'styled-components';
import UnauthenticatedUser from '../../components/UnauthenticatedUser';
import AllUsers from '../../contexts/AllUsers';
import MyLinks from './MyLinks';


const StyledDashboard = styled.div`
  width: 100%;
  margin: 0 auto;
  text-align: center;

  .pageTitle {
    font-weight: 400;
    font-size: 35px;
  }
`;

const MyLinksEnterance = () => {
    const userData = useContext(UserProvider.Context);

    return (
        <StyledDashboard>
            {userData ? (
                <>
                    <MyLinks user={userData} />

                </>
            ) : (
                <UnauthenticatedUser />
            )}
        </StyledDashboard>
    );
};

export default MyLinksEnterance
    ;
