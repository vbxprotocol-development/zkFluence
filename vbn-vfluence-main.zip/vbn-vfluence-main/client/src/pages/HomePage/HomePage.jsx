import React, { useEffect } from 'react'
import './homePage.css'
import { useState, createContext } from 'react';
import NavBar from '../../components/NavBar';
import Axios from 'axios';
import api from '../../api'
import moment from 'moment'
import { Link } from 'react-router-dom';
import inputArrow from '../../assets/images/inputArrow.svg'
import yellowVBX from '../../assets/images/yellowVBX.svg'
import arrowIcon from '../../assets/images/arrowIcon.svg'
import arrow from '../../assets/images/arrows.svg'
import copyIcon from '../../assets/images/copy.svg'
import showAllButton from '../../assets/images/showAll.svg'
import ReactPaginate from 'react-paginate'
import arrowPaginationForward from '../../assets/images/arrowPaginationForward.svg'
import arrowPaginationBackward from '../../assets/images/arrowPaginationBackward.svg'
import CreateBountyCard from '../Bounty/CreateBountyCard'
import BountyEnterance from '../Bounty';
import { useWindowWidth } from '../../components/functions/useWindowWidth';

const Context = createContext('');

const HomePage = ({ user, users }) => {

    const [myBounties, setMyBounties] = useState([])
    const [topBounties, setTopBounties] = useState([])
    // const [bountyDetails, setBountyDetails] = useState([])
    const [id, setID] = useState()
    const [page1, setPage1] = useState(true)
    const [popup, setPopup] = useState(false)
    const [currentPromoLink, setCurrentPromoLink] = useState()
    const [contentLink, setContentLink] = useState()
    const [offset, setOffset] = useState(0);
    const [perPage] = useState(6);
    const [pageCount, setPageCount] = useState(0)
    const [offsetMyBounties, setOffsetMyBounties] = useState(0);
    const [perPageMyBounties] = useState(3);
    const [pageCountMyBounties, setPageCountMyBounties] = useState(0)
    const [bountyModal, setBountyModal] = useState(false)

    const [title, setTitle] = useState('')
    const [description, setDescription] = useState('')
    const [contentImage, setContentImage] = useState(null)

    const [showAll, setShowAll] = useState(false)
    const [showAllClass, setShowAllClass] = useState('flexHomePage myCardData')
    const handleShowAllClick = () => {
        setShowAll(!showAll)
        setShowAllClass(showAll ? 'flexHomePage myCardData' : 'show-all-button-clicked')
    }


    const [sortMethod, setSortMethod] = useState('')
    const [sortedClassTrending, setSortedClassTrending] = useState('sortTrending')
    const [sortedClassTraffic, setSortedClassTraffic] = useState('sortByClicks')
    const [sortedClassPayout, setSortedClassPayout] = useState('sortBounty')
    const [sortedClassNewest, setSortedClassNewest] = useState('sortByExp')

    const handleSort = (sort) => {
        setSortMethod(sort);
        if (sort == 'bounty') {
            setSortedClassPayout('sortedBounty')
            setSortedClassNewest('sortByExp')
            setSortedClassTraffic('sortByClicks')
            setSortedClassTrending('sortTrending')

        } else if (sort == 'expirationDate') {
            setSortedClassNewest('sortedByExp')
            setSortedClassTraffic('sortByClicks')
            setSortedClassTrending('sortTrending')
            setSortedClassPayout('sortBounty')

        } else if (sort == 'counter') {
            setSortedClassTraffic('sortedByClicks')
            setSortedClassTrending('sortTrending')
            setSortedClassPayout('sortBounty')
            setSortedClassNewest('sortByExp')

        } else if (sort == 'trending') {
            setSortedClassTrending('sortedTrending')
            setSortedClassPayout('sortBounty')
            setSortedClassNewest('sortByExp')
            setSortedClassTraffic('sortByClicks')
        }
    }

    const sortedBounties = [...topBounties].sort((a, b) => {
        if (sortMethod === 'bounty') {
            return b.bounty - a.bounty;
        } else if (sortMethod === 'expirationDate') {
            return new Date(b.createdAt) - new Date(a.createdAt);
        } else if (sortMethod === 'counter') {
            return b.counter - a.counter;
        }
    });

    let myArr = []
    const getMyBounties = async () => {
        try {
            await api
            Axios.get(`/bounty/yourBounty/${user.displayName}`)
                .then(res => {
                    res.data.forEach((bounties) => {
                        if (bounties.expirationDate !== undefined && moment().isBefore(bounties.expirationDate) && bounties.tags.length < 2 && bounties.tags != "")
                            myArr.push(bounties)
                    });
                    // setPageCountMyBounties(Math.ceil(myArr.length / perPageMyBounties))
                    setMyBounties(myArr)
                })
        } catch (e) {
            console.log(e)
        }
    }
    const handlePageClickMyBounties = (e) => {
        const selectedPage = e.selected;
        setOffsetMyBounties((selectedPage) * perPageMyBounties)
    }

    // const getMyLinks = async () => {
    //     try {
    //         await api
    //         Axios.get(`/link/promoter/${user.displayName}`)
    //             .then(res => {
    //                 setMyLinks(res.data)
    //             })
    //     } catch (e) {
    //         console.log(e)
    //     }
    // }

    let arr = []
    const getTopBounties = async (e) => {
        try {
            await api
            Axios.get(`/bounty/all`)
                .then(res => {
                    setTopBounties(res.data)
                })

        } catch (e) {
            alert(e)
        }
    }

    const handlePageClick = (e) => {
        const selectedPage = e.selected;
        setOffset((selectedPage) * perPage)
    }

    const togglePopUp = () => { setPopup(!popup); copyURL() }

    const toggleBountyModal = (e) => {
        if (e.type === 'click') {
            e.preventDefault();
            setBountyModal(true);
            onAdd()
        } else if (e.type === 'keydown' && e.key === 'Enter') {
            e.preventDefault();
        }
    };

    useEffect(() => {
        const handleKeyDown = (e) => {
            toggleBountyModal(e);
        };

        document.addEventListener('keydown', handleKeyDown);

        return () => {
            document.removeEventListener('keydown', handleKeyDown);
        };
    }, [bountyModal]);

    function copyURL() {
        if (!navigator.clipboard) {
            fallbackCopyURL()
            return
        }
        navigator.clipboard.writeText(currentPromoLink).then(function () {
            console.log('Copying is complete')
        }, function (err) {
            console.error('Copying failed', err)
        })
    }

    function fallbackCopyURL() {
        var input = document.createElement('input')
        input.setAttribute('value', currentPromoLink)
        document.body.appendChild(input)
        input.focus()
        input.select()
        try {
            document.execCommand('copy')
        } catch (e) {
            console.log(e)
        }
        document.body.removeChild(input)
    }

    let sum = 0
    let bountyDetails = []


    //Refactored all of this to streamline checking whether user has a link and if not to run the link generation POST request.
    //NEEDS VERY HEAVY TESTING.
    const fullBountyDetails = async () => {
        try {
            await api
            Axios.get(`/link/promoter/${user.firstName}`)
                .then(res => {

                    if (res.data.filter((ele) => ele.bountyId.includes(id.toString())).length >= 1) {
                        console.log(res.data)
                        res.data.forEach((element) => {
                            if (id == element.bountyId) {
                                setCurrentPromoLink(element.shortUrl)
                                togglePopUp()
                                return { currentPromoLink }
                            }
                        })
                        console.log('stage')
                    } else {
                        setCurrentPromoLink()
                        try {

                            Axios.get(`/bounty/ID/${id}`)
                                .then(res => {
                                    bountyDetails.push(res.data)
                                    console.log(res.data)
                                    return { bountyDetails }
                                })
                                .then(() => {
                                    if (bountyDetails) {
                                        promo()
                                    } else {
                                        console.log('no deets')
                                    }
                                }

                                )
                        } catch (e) {
                            console.log(e)
                        }

                        console.log('skipped')

                    }
                })

        } catch (e) {
            console.log(e)
        }

    }

    const promo = async (e) => {

        if (!currentPromoLink) {
            console.log(bountyDetails)
            const post = {
                baseUrl: "https://vfluence-alpha-theta.vercel.app/link/",
                creator: user.firstName,
                creatorImg: user.image,
                creatorDisplayName: user.displayName,
                counter: 0,
                bountyId: bountyDetails[0]._id,
                title: bountyDetails[0].title,
                description: bountyDetails[0].description,
                author: bountyDetails[0].creator,
                url: bountyDetails[0].originalUrl,
                image: bountyDetails[0].image,
                expirationDate: bountyDetails[0].expirationDate,
                target: bountyDetails[0].target,
                bounty: bountyDetails[0].bounty,
                dates: [{
                    date: new Date(),
                    clicks: 0
                }]
            }
            try {
                await api
                Axios.post('/link/', post)
                    .then(res => {
                        console.log(res)
                        setCurrentPromoLink(res.data.shortUrl)
                        togglePopUp()
                    })

            } catch (e) {
                alert(e)
            }
        } else {
            console.log(currentPromoLink)
        }
    }

    // const fullLinkDetails = async (e) => {
    //     e.preventDefault()

    //     try {
    //         await api
    //         Axios.get(`/link/linkID/${linkID}`)
    //             .then(res => {
    //                 setLinkDetails(res.data)
    //             })
    //     } catch (e) {
    //         console.log(e)
    //     }
    // }
    const onAdd = async (e) => {

        const post = {
            baseUrl: "http://localhost:3000",
            url: contentLink,
        }
        try {
            await api
            Axios.post('/bounty/addLink', post)
                .then(res => {
                    setTitle(res.data.title)
                    setDescription(res.data.description)
                    setContentImage(res.data.image)

                })

        } catch (e) {
            alert(e)
        }
    }

    const currentDate = moment().format('YYYY-MM-DD')

    const windowWidth = useWindowWidth()

    useEffect(() => {
        getMyBounties()
        // getMyLinks()
    }, [offsetMyBounties]);

    useEffect(() => {
        getTopBounties()
    }, [offset])

    return (
        <>


            <div className='home'>
                <NavBar className="NavBar" />
                <div className='homePageBackground'>
                    {page1 && (
                        <>

                            <div className='flexHomePage'>

                                <div className='section2'>
                                    <div className=''>

                                        {myBounties.length > 0 ?
                                            <div className={showAll ? 'enterLinkAll' : 'upperSection'}>
                                                <div className='createAnotherBounty'>
                                                    <p>Enter a link to your content,<br />create a bounty and unlock the<br /> power of the network</p>
                                                    <form>
                                                        <div>Link:</div>
                                                        <input
                                                            type="text"
                                                            placeholder='https://www...'
                                                            onChange={(event) => {
                                                                setContentLink(event.target.value)
                                                            }}
                                                            value={contentLink}
                                                            required
                                                            className='contentLinkInput'
                                                        />
                                                        {/* <Link to={{ pathname: "/bounty", state: { contentLink: contentLink } }}> */}
                                                        <img src={inputArrow} onClick={toggleBountyModal} />
                                                        {/* </Link> */}
                                                    </form>

                                                </div>
                                                <span className='spanLatestBounties'>MY LATEST BOUNTIES</span>

                                                <div className={showAllClass}>

                                                    {myBounties.slice(0, showAll ? myBounties.length : 3).map(bounties =>
                                                        <div className='myCards'>
                                                            <div className='myBountyDetails'>
                                                                <span>Launch date  {moment(bounties.createdAt).format('MM/DD/YYYY')}</span>
                                                                <h4 className='myTitle' >{bounties.title.length > 57 ? bounties.title.slice(0, 53) + "..." : bounties.title}</h4>
                                                                <p className='myDescription'>{bounties.description.length > 100 ? bounties.title.length > 57 ? bounties.description.slice(0, 80) + '...' : bounties.description.slice(0, 109) + '...' : bounties.description}</p>
                                                            </div>
                                                            <div className='myBountyDivider'></div>
                                                            <div className='myBountySpan'>
                                                                <span className='myBountyTarget'>Target <span>{bounties.target}</span></span>
                                                                <span className='myBountyClicks'>Clicks <span>{bounties.counter ? bounties.counter : 0}</span></span>
                                                            </div>

                                                        </div>)
                                                    }
                                                    <div className='showBtnSection'>
                                                        <div onClick={handleShowAllClick} className={showAll ? 'showLessBtn' : 'showAllBtn'}>{showAll ? "Show Less" : "Show All"}</div>
                                                    </div>
                                                </div>

                                            </div> :
                                            <div className='enterLink2'>
                                                <div className='createABounty'>
                                                    <div className='gotSomething'>
                                                        <p>Enter a link to your content,<br /> create a bounty and unlock the<br /> power of the network</p>
                                                        <span>Bounties you create will appear here</span>
                                                    </div>
                                                    <form>
                                                        <div>Link:</div>
                                                        <input
                                                            type="text"
                                                            placeholder='https://www...'
                                                            onChange={(event) => {
                                                                setContentLink(event.target.value)
                                                            }}
                                                            value={contentLink}
                                                            className='linkform' />
                                                        {/* <Link to={{ pathname: "/bounty", state: { contentLink: contentLink } }}> */}
                                                        <img src={inputArrow} onClick={toggleBountyModal} />
                                                        {/* </Link> */}
                                                    </form>
                                                </div>
                                            </div>}

                                    </div>
                                    <div className='middleSection'>
                                        <div className='sortButtons'>
                                            <div className={sortedClassTrending ? 'radiusClass' : null}>
                                                <button onClick={() => handleSort('trending')} className={sortedClassTrending}>Trending</button>
                                            </div>
                                            <div className={sortedClassTraffic ? 'radiusClass' : null}>
                                                <button onClick={() => handleSort('counter')} className={sortedClassTraffic}>Highest Traffic</button>
                                            </div>
                                            <button onClick={() => handleSort('bounty')} className={sortedClassPayout}>Largest Payout</button>
                                            <button onClick={() => handleSort('expirationDate')} className={sortedClassNewest}>Newest</button>
                                        </div>
                                        {windowWidth > 600 ? <span className='spanLast50'>Showing Last 50 Bounties</span> : null}


                                    </div>

                                    <div className='allBounties'>
                                        {sortedBounties.map(bounties =>
                                            <div className='topBountyBackground'>
                                                <div className='topBountyCard' onMouseEnter={() => setID(bounties._id)}>
                                                    <Link to={{ pathname: "/bountyDetails", state: { id: id } }} className='tbLink'>
                                                        <div className='topBountyImageSection'>
                                                            <img src={bounties.image} className={bounties.image ? 'topBountyImage' : 'topBountyImageBroken'} /></div>
                                                        <div> <div>@{bounties.creator}</div></div>
                                                        <div className='tbSection1'>
                                                            <div className='tbCreator'>{
                                                                <div>{moment(bounties.expirationDate).diff(currentDate, 'days') >= 7 ?
                                                                    Math.floor(moment(bounties.expirationDate).diff(currentDate, 'days') / 7) + ' Weeks Remaining' :
                                                                    moment(bounties.expirationDate).diff(currentDate, 'days') + ' Days Remaining'
                                                                }

                                                                </div>
                                                            }</div>
                                                            <div className='tbTitle'>{bounties.title.length > 60 ? bounties.title.slice(0, 52) + '...' : bounties.title}</div>

                                                        </div>
                                                        {/* <div className='tbPayout'>${(bounties.counter) * bounties.bounty * .20 ? (bounties.counter) * bounties.bounty * .20 : 0} per click</div> */}
                                                    </Link>
                                                    <div className='tbFooter' >
                                                        <div className='tbFooterSection1'>
                                                            <div className='tbBountyAmount'>BOUNTY

                                                                <div className='tbBountyFooter'>

                                                                    <img src={yellowVBX} />
                                                                    <div className='bountyOptions'>
                                                                        <div>{bounties.bounty} VBX</div>
                                                                        <div>${bounties.bounty * 0.2}</div>
                                                                    </div>
                                                                </div>

                                                            </div>
                                                        </div><div className='tbFooterSection2' >
                                                            <div className='tbTargetClicks'>TARGET <div>{bounties.target}</div></div>
                                                            <div className='tbGeneratedClicks'>CLICKS <div>{bounties.counter > 0 ? bounties.counter : 0}</div></div>
                                                            <img src={arrowIcon} onClick={() => { fullBountyDetails() }} style={{ cursor: "pointer" }} />
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        )
                                        }

                                    </div>
                                </div>
                            </div>
                        </>
                    )
                    }
                    {
                        popup && (
                            <div className="Popup">
                                <div onClick={togglePopUp} className="overlay"></div>
                                <div className="Popup-content">
                                    <div>
                                        <img src={arrow} /></div>
                                    <div className='popupMessage'>Personalized link coped to clipboard! Share link anywhere <br />and earn based on clicks generated</div>
                                    <div className='URL'>Personalized URL: {currentPromoLink}<img src={copyIcon} onClick={copyURL} />
                                    </div></div>
                            </div>

                        )
                    }


                    {
                        bountyModal && (
                            <BountyEnterance contentLink={contentLink} titleHP={title} descriptionHP={description} contentImageHP={contentImage} setBountyModal={setBountyModal} bountyModal={bountyModal} />
                        )
                    }

                </div > </div></>
    )
}


HomePage.Context = Context

export default HomePage