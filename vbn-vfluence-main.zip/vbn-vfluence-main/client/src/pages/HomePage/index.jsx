import React, { useContext } from 'react';
import UserProvider from '../../contexts/UserProvider';
import styled from 'styled-components';
import UnauthenticatedUser from '../../components/UnauthenticatedUser';
import AllUsers from '../../contexts/AllUsers';
import HomePage from './HomePage';

const StyledDashboard = styled.div`
  width: 100%;
  margin: 0 auto;
  text-align: center;

  .pageTitle {
    font-weight: 400;
    font-size: 35px;
  }
`;

const HomeEnterance = () => {
    const userData = useContext(UserProvider.Context);
    const usersData = useContext(AllUsers.Context)
    return (
        <StyledDashboard>
            {usersData && userData ? (
                <>
                    <HomePage user={userData} users={usersData} />

                </>
            ) : (
                <UnauthenticatedUser />
            )}
        </StyledDashboard>
    );
};

export default HomeEnterance
    ;
