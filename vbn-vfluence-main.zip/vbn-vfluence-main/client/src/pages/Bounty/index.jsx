import React, { useContext } from 'react';
import UserProvider from '../../contexts/UserProvider';
import styled from 'styled-components';
import UnauthenticatedUser from '../../components/UnauthenticatedUser';
import Bounty from '../../contexts/Bounty';
import CreateBountyCard from './CreateBountyCard';
import AllUsers from '../../contexts/AllUsers';

const StyledDashboard = styled.div`
  width: 100%;
  margin: 0 auto;
  text-align: center;

  .pageTitle {
    font-weight: 400;
    font-size: 35px;
  }
`;

const BountyEnterance = ({ contentLink, titleHP, descriptionHP, contentImageHP, bountyModal, setBountyModal }) => {
    const userData = useContext(UserProvider.Context);
    const usersData = useContext(AllUsers.Context)
    return (
        <StyledDashboard>
            {userData ? (
                <>
                    <CreateBountyCard user={userData} users={usersData} contentLink={contentLink} titleHP={titleHP} descriptionHP={descriptionHP} contentImageHP={contentImageHP} setBountyModal={setBountyModal} bountyModal={bountyModal} />

                </>
            ) : (
                <UnauthenticatedUser />
            )}
        </StyledDashboard>
    );
};

export default BountyEnterance
    ;
