import React, { useEffect, useRef } from 'react'
import { useState, createContext, useContext } from 'react';
import Bounty from '../../contexts/Bounty';
import NavBar from '../../components/NavBar';
import { Link, useLocation } from 'react-router-dom';
import Axios from 'axios';
import api from '../../api'
import './StyledCreateBountyCard.css'
import uploadImage from '../../assets/images/uploadImage.svg'
import defaultImage from '../../assets/images/defaultImage.svg'
import styled from 'styled-components';
import moment from 'moment';
import arrowUp from '../../assets/images/arrowUpBountyExpiration.svg'
import arrowDown from '../../assets/images/arrowDownBountyExpiration.svg'

const Context = createContext('');

const DropDownContainer = styled("div")`
font-family: 'GT Pressura';
font-style: normal;
font-weight: 400;
font-size: 14px;
line-height: 20px;
width: 320px;
height: 20px;
text-align: left;
color: #344054;
z-index: 1;
`;

const DropDownHeader = styled("div")`
width: 306px;
height: 20px;
padding-top: 10px;
padding-bottom: 10px;
padding-left: 14px;

gap: 8px;
background: #FFFFFF;
border: 1px solid #D0D5DD;
box-shadow: 0px 1px 2px rgba(16, 24, 40, 0.05);
border-radius: 8px;
`;

const DropDownListContainer = styled("div")`
margin-top: -16px
`;

const DropDownList = styled("ul")`
height: 250px
display: flex;
flex-direction: column;
align-items: flex-start;
justify-content: space-evenly;
padding: 3px 14px 0;
gap: 8px;
background: #FFFFFF;
border: 1px solid #D0D5DD;
box-shadow: 0px 1px 2px rgba(16, 24, 40, 0.05);
border-radius: 8px;
  }
`;

const ListItem = styled("li")`
  list-style: none;
  height: 48px;
  display: flex;
  align-items:center;

  cursor: pointer; 
`;

const options = ["In 1 Week", "In 2 Weeks", "In 3 Weeks", "In 4 Weeks", "In 2 Months"];

const CreateBountyCard = ({ user, users, contentLink, titleHP, descriptionHP, contentImageHP, bountyModal, setBountyModal }) => {

    // const location = useLocation()
    // const { contentLink } = location.state

    const [title, setTitle] = useState('')
    const [description, setDescription] = useState('')
    const [vbx, setVbx] = useState('')
    const [target, setTarget] = useState('')
    const [tags, setTags] = useState([])
    const [vFluencer, setVFluencer] = useState([])
    const [expirationDate, setExpirationDate] = useState()
    const [content, setContent] = useState('')
    const [contentImage, setContentImage] = useState(null)
    const [isOpen, setIsOpen] = useState(false);
    const [selectedOption, setSelectedOption] = useState(null);


    const [page1, setPage1] = useState(true)
    const [page2, setPage2] = useState(false)
    const [page3, setPage3] = useState(false)
    const [finalPage, setFinalPage] = useState(false)

    const togglePage2 = () => { setPage1(!page1); setPage2(!page2) }
    const togglePage3 = () => { setPage2(!page2); setPage3(!page3) }
    const togglePage4 = () => { setPage2(!page2); setFinalPage(!finalPage) }
    const toggleFinalPage = () => { setFinalPage(!finalPage); setBountyModal(!bountyModal); window.location.reload() }
    const toggling = () => setIsOpen(!isOpen);



    const onOptionClicked = value => () => {
        setSelectedOption(value);
        setExpirationDate(value.includes('1') ? moment().add(7, 'days').calendar() : value.includes('2 Weeks') ? moment().add(14, 'days').calendar() : value.includes('3') ? moment().add(21, 'days').calendar() : value.includes('4') ? moment().add(30, 'days').calendar() : value.includes('2 Months') ? moment().add(60, 'days').calendar() : null)
        setIsOpen(false);
        console.log(selectedOption);
    };

    //Image Drag & Drop Feature from Desktop to Web App.
    const dropZoneRef = useRef(null);
    const onDragEnter = (e) => {
        e.preventDefault();
        dropZoneRef.current.classList.add('highlight');
    };

    const onDragOver = (e) => {
        e.preventDefault();
    };

    const onDrop = (e) => {
        e.preventDefault();
        const file = e.dataTransfer.files[0];
        console.log(file);
        dropZoneRef.current.classList.remove('highlight');
        TransformFileData(file)
    };

    const handleChange = event => {
        var selectedSkills = Array.from(event.target.selectedOptions, (item) => item.value)
        setTags(selectedSkills);
    };

    const handleVFluencers = event => {
        var selectedSkills = Array.from(event.target.selectedOptions, (item) => item.value)
        setVFluencer(selectedSkills);
    };

    const handleProductImageUpload = (e) => {
        const file = e.target.files[0];
        TransformFileData(file);
    };

    const TransformFileData = (file) => {
        const reader = new FileReader();

        if (file) {
            reader.readAsDataURL(file);
            reader.onloadend = () => {
                setContentImage(reader.result);
            };
        } else {
            setContentImage("");
        }
    };

    // const onAdd = async (e) => {
    //     e.preventDefault()
    //     const post = {
    //         baseUrl: "http://localhost:3000",
    //         url: content,
    //     }
    //     try {
    //         await api
    //         Axios.post('/bounty/addLink', post)
    //             .then(res => {
    //                 setTitle(res.data.title)
    //                 setDescription(res.data.description)
    //                 setContentImage(res.data.image)

    //             })
    //             .then(alert('Content has been added'))
    //     } catch (e) {
    //         alert(e)
    //     }
    // }

    useEffect(() => {
        function checkforData() {
            if (contentLink) {
                setContent(contentLink)
            } if (titleHP) {
                setTitle(titleHP)
            } if (descriptionHP) {
                setDescription(descriptionHP)
            } if (contentImageHP) {
                setContentImage(contentImageHP)
            } else {
                return null
            }
        }
        checkforData()

    }, [titleHP, descriptionHP, contentImageHP])

    const inputRef = useRef(null);
    const inputClicksRef = useRef(null);

    const handleVbxChange = (event) => {
        setVbx(event.target.value);
    };

    useEffect(() => {
        if (vbx.endsWith('VBX')) {
            return; // Don't add suffix if already present at the end
        }
        const vbxIndex = vbx.indexOf('VBX');
        if (vbxIndex >= 0) {
            setVbx(vbx.slice(0, vbxIndex + 3)); // Remove suffix if present in the middle
        }
        if (vbx.length > 0 && !vbx.endsWith('VBX')) {
            setVbx(`${vbx.trim()} VBX`); // Add suffix to input value
        }
    }, [vbx]);

    useEffect(() => {
        const inputElement = inputRef.current;
        if (inputElement) {
            inputElement.setSelectionRange(inputElement.value.length - 4, inputElement.value.length - 4);
            inputElement.focus();
        }
    }, [vbx]);


    const handleClicksChange = (event) => {
        setTarget(event.target.value);
    };

    useEffect(() => {
        if (target.endsWith('Clicks')) {
            return; // Don't add suffix if already present at the end
        }
        const clicksIndex = target.indexOf('Clicks');
        if (clicksIndex >= 0) {
            setTarget(target.slice(0, clicksIndex + 3)); // Remove suffix if present in the middle
        }
        if (target.length > 0 && !target.endsWith('Clicks')) {
            setTarget(`${target.trim()} Clicks`); // Add suffix to input value
        }
    }, [target]);

    useEffect(() => {
        const inputElement = inputClicksRef.current;
        if (inputElement) {
            inputElement.setSelectionRange(inputElement.value.length - 7, inputElement.value.length - 7);
            inputElement.focus();
        }
    }, [target]);


    const [pricePerClick, setPricePerClick] = useState()

    useEffect(() => {
        if (vbx && target) {
            setPricePerClick((vbx.replace(/,/g, '').match(/\d+/)[0] / target.replace(/,/g, '').match(/\d+/)[0]) * 0.2)
        }
    }, [vbx, target])



    return (
        <div className='createBountybackground'>

            {page1 && (
                <div className='bountyCreationSection1'>
                    <div className='upperSectionBountyCreation1'>
                        <div className='tapSection'>
                            <div className='tapTitle'>Tap Into The Network</div>
                            <div className='tapDesc'>Time to power up your content. Enter the details for your new bounty</div>
                        </div>
                        <div className='closeOut' onClick={() => { setBountyModal(!bountyModal) }}>x</div>
                    </div>


                    <form className='createBountyForm'>
                        <div className='URLSection'>
                            <div className='targetURL'>Target URL<span>*</span></div>
                            <input
                                type="text"
                                placeholder=''
                                onChange={(event) => {
                                    setContent(event.target.value)
                                }}
                                // onLoadedData={() => { content ? setContent(content) : contentLink ? setContent(contentLink) : setContent('') }}
                                value={content}
                                className='targetURLInput'
                            />
                        </div>
                        <div className='bountyExpiration' >
                            <div className='bountyDurationTitle'>Bounty Duration*</div>
                            <DropDownContainer>
                                <DropDownHeader onClick={toggling}>{selectedOption || "Select Expiration Date"}{isOpen ? <img src={arrowDown} className="arrowExp" /> : <img src={arrowUp} className="arrowExp" />}</DropDownHeader>

                                {isOpen && (<DropDownListContainer>
                                    <DropDownList>
                                        {options.map(option => (
                                            <ListItem onClick={onOptionClicked(option)} key={Math.random()} className="listItemHover">
                                                {option}
                                            </ListItem>
                                        ))}
                                    </DropDownList>
                                </DropDownListContainer>)}

                            </DropDownContainer>

                        </div>
                        <div className='bountyExpirationDesc'>Shorter bounties create urgency. Longer <br />bounties have more time to spread. </div>
                        <div className='divider'><h1></h1></div>

                        <div className=''>
                            <div className=''>

                                <div className='imageUploadSection'>
                                    <div className='imageUploadtitle'>Preview image <span>*</span></div>
                                    <div className='imageUploadInnerSection'>
                                        {contentImage ?

                                            <img src={contentImage} alt="placeholder" className='uploadedImage' />

                                            :
                                            <img src={uploadImage} alt='placeholder' className='uploadImage' />
                                        }

                                        <label class="custom-file-upload">
                                            <div className="drop-zone"
                                                ref={dropZoneRef}
                                                onDragEnter={onDragEnter}
                                                onDragOver={onDragOver}
                                                onDrop={onDrop}>
                                                <div className='firstLine'><strong>Click to upload</strong><div> or drag and drop</div></div>
                                                <div className='secondLine'>SVG, PNG, JPG {'('}if left empty one will be generated automatically{')'}</div>
                                            </div>
                                            <input
                                                id="imgUpload"
                                                accept="image/*"
                                                type="file"
                                                onChange={handleProductImageUpload}
                                                required
                                            />
                                        </label>
                                    </div>
                                </div>
                                <div className='divider2'></div>

                                <div className='bountyCreationTitleSection'>
                                    <div className='bountyCreationTitle'>Title*</div>
                                    <input
                                        type="text"
                                        placeholder='Title here'
                                        onChange={(event) => {
                                            setTitle(event.target.value)
                                        }}
                                        value={title}
                                        className='bountyCreationTitleInput'
                                        required
                                    />
                                </div>

                                <div className='bountyCreationDescriptionSection'>
                                    <div className='bountyCreationDescription'>Description*</div>
                                    <textarea
                                        type="text"
                                        placeholder='Write a few sentences about the link...'
                                        onChange={(event) => {
                                            setDescription(event.target.value)
                                        }}
                                        value={description}
                                        className='bountyCreationDescriptionInput'
                                        required
                                        wrap='soft'
                                        align="top"
                                    />
                                </div>
                                <div className='bountyCreationTagsSection'>
                                    <div className='bountyCreationTags'>Tags*</div>
                                    <textarea
                                        type="text"
                                        placeholder='Add 1-10 keywords that help users find your content. ex: Fashion, Music, Artwork, Work For Hire'
                                        onChange={(event) => {
                                            setTags(event.target.value)
                                        }}
                                        value={tags}
                                        className='bountyCreationTagsInput'
                                        required
                                        wrap='soft'
                                        align="top"
                                    />
                                    {/* <select multiple={true} value={tags} onChange={handleChange} className='tagSelector'>
                                        <option value="Fashion">Fashion </option>
                                        <option value="Home Improvement">Home Improvement </option>
                                        <option value="Rap">Rap </option>
                                        <option value="Comedy">Comedy </option>
                                        <option value="News">News </option>
                                        <option value="World Events">World Events </option>
                                    </select> */}

                                </div>
                                <div className='divider3'></div>
                                <div className='buttonSection'>
                                    <button className='backBtn' onClick={() => { setBountyModal(!bountyModal) }}>Cancel</button>
                                    <div className='borderBackground'>
                                        <button onClick={togglePage2} className='nextBtn'><div>Next</div></button></div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            )}

            {page2 && (
                <div className='bountyCreationSection2'>
                    <div className='upperSectionBountyCreation2'>
                        <div className='setSection'>
                            <div className='setTitle'>Set Your Reach</div>
                            <div className='setDesc'>How many people do you want to reach and how much are your offering?</div>
                        </div>
                        <div className='closeOut2' onClick={() => { setBountyModal(!bountyModal) }}>x</div>

                        <form className='createBountyForm2'>

                            <input
                                type="text"
                                placeholder='Bounty in VBX'
                                value={vbx} onChange={handleVbxChange} ref={inputRef}
                                className='vbx'
                                required
                            />

                            <div>FOR</div>
                            <input
                                type="text"
                                placeholder='Target'
                                onChange={handleClicksChange}
                                ref={inputClicksRef}
                                value={target}
                                className='target'
                                required
                            />
                        </form>

                        <div className='divider4'></div>
                        <div className='PPC'>
                            <div>Price per click</div>
                            <div>${pricePerClick ? pricePerClick.toFixed(2) : 0}</div>
                        </div>

                    </div>

                    <div className='divider5'></div>
                    <div className='buttonSection2'>
                        <button className='backBtn2' onClick={togglePage2}>Back</button>
                        <div className='borderBackground2'>
                            <button className='nextBtn2' onClick={togglePage4}><div>Next</div></button>
                        </div>
                    </div>
                </div>)}

            {/* {page3 && (
                <div>
                    <div className=''>
                        <div>
                            <form>
                                <h2 className='page3Title'>Recommended VFluencers</h2>
                                <div>This will be updated as requested. To select
                                    multiple tags hold Ctrl or Cmd.</div>
                                <select className="pageTitle" onChange={handleVFluencers}
                                    value={vFluencer} multiple={true}>

                                    {users.map(users =>
                                        <option>{users.displayName}</option>
                                    )}</select>

                            </form>

                        </div>
                    </div>
                    <button onClick={togglePage3} className='backBtn'>Back</button>
                    <button onClick={togglePage4} className='nextBtn'>Next</button>
                </div>)} */}

            {finalPage && (

                <Context.Provider value={{ title, description, vbx, target, tags, vFluencer, expirationDate, content, contentImage }}>

                    <div className='bountyCreationSection3'>
                        <div className='upperSectionBountyCreation3'>
                            <div className='bountyPreviewSection'>
                                <div className='bountyPreviewTitle'>Bounty Preview</div>
                                <div className='bountyPreviewDesc'>Ready to launch your bounty?</div>
                            </div></div>
                        <div className='closeOut3' onClick={() => { setBountyModal(!bountyModal) }}>x</div>
                        <div className='finalizeBounty'>
                            <div className='finalTitle'>{title}</div>
                            <div className='finalImage'>{contentImage ?

                                <img src={contentImage} alt="placeholder" className='finalImage' />

                                :
                                <img src={defaultImage} alt='placeholder' className='finalImage' />
                            }
                            </div>


                            <div className='finalTarget'>
                                <div className='finalTargetDetails'>
                                    <div className='finalBounty'>Bounty: {vbx}</div>
                                    <div className='finalTargetClicks'>Target: {target}</div>
                                </div>
                            </div>
                        </div>


                        <div className='finalDetailsSection'>
                            <div className='finalExpiration'>Expires: {expirationDate} </div>
                            <p className='fE'></p>


                            <div className='finalTags'>Tags <div className='fT'>{tags}</div></div>


                            <div className='finalDesc'>Link Description</div>
                            <p className='fD'>{description.length > 293 ? description.slice(0, 290) + '...' : description}</p>



                            {/* <div className=''>Expiration Date</div>
                            <input
                                type="date"
                                onChange={(e) => {
                                    setExpirationDate(e.target.value)
                                }}
                                value={expirationDate}
                                required
                            /> */}

                        </div>

                    </div>

                    <div className='divider6'></div>
                    <div className='finalButtonSection'>
                        <button className='backBtn3' onClick={togglePage4}>Back</button>
                        <Bounty user={user} toggleFinalPage={toggleFinalPage} />
                    </div>
                </Context.Provider>)}

        </div>



    )
}


CreateBountyCard.Context = Context

export default CreateBountyCard