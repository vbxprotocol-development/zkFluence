import React from 'react';
import { BrowserRouter, Route } from 'react-router-dom';
import UserProvider from './contexts/UserProvider';
import Home from './pages/Home';
import Dashboard from './pages/Dashboard';
import BountyEnterance from './pages/Bounty';
import AllUsers from './contexts/AllUsers';
import HomeEnterance from './pages/HomePage';
import ProfileEnterance from './pages/Profile/index'
import BountyDetailsEnterance from './pages/BountyDetails';
import BountyDetails from './pages/BountyDetails/bounty';
import MyLinksEnterance from './pages/MyLinks';
import WalletEnterance from './pages/Wallet';



const App = () => {
  return (
    <BrowserRouter basename='/'>
      <UserProvider>
      <Route path="/dashboard" component={Dashboard} />
      <Route path="/profile" exact component={ProfileEnterance} />
      <Route path="/wallet" exact component={WalletEnterance} />
      <AllUsers>
        <Route path="/bounty" exact component ={BountyEnterance} />
        <Route path="/bountyDetails" component={BountyDetailsEnterance}/>
        </AllUsers>
 
        <AllUsers>
        <Route path="/home" exact component={HomeEnterance} />
        <Route path="/myLinks" exact component={MyLinksEnterance} />
        </AllUsers>

      </UserProvider>
      
      <Route path="/" exact component={Home} />
      
    </BrowserRouter>
  );
};

export default App;
