import React from 'react';
import Axios from 'axios';
import { useState } from 'react';
import api from '../api';
import YourBounty from './YourBounty';
import AllBounties from './AllBounties';
import styled from 'styled-components';
import CreateBountyCard from '../pages/Bounty/CreateBountyCard';
import { useContext } from 'react';
import { ethers } from 'ethers';
import BountyContract from "../artifacts/contracts/vbnBounty.sol/BountyContract.json";
const { getAddress } = require("@ethersproject/address");


const Bounty = ({ user, toggleFinalPage }) => {
    const bountyData = useContext(CreateBountyCard.Context)
    const [threshold, setThreshold] = useState('')
    const [expirationDate, setExpirationDate] = useState()

    const contractAddress = '0xCf7Ed3AccA5a467e9e704C703E8D87F634fB0Fc9';
    const validatedAddress = ethers.utils.getAddress(contractAddress);
    const provider = new ethers.providers.JsonRpcProvider('http://127.0.0.1:8545/');
    const signer = provider.getSigner();
    const contract = new ethers.Contract(validatedAddress, BountyContract.abi, signer);

    const onSubmit = async (e) => {
        e.preventDefault()

        const post = {
            title: bountyData.title,
            description: bountyData.description,
            creator: user.displayName,
            expirationDate: bountyData.expirationDate,
            tags: bountyData.tags,
            target: bountyData.target.replace(/,/g, '').match(/\d+/)[0],
            bounty: bountyData.vbx.replace(/,/g, '').match(/\d+/)[0],
            vFluencer: bountyData.vFluencer,
            originalUrl: bountyData.content,
            image: bountyData.contentImage
        }



        try {
            const tx = await contract.createBounty(post);
            const receipt = await tx.wait();
            console.log(receipt);
        } catch (error) {
            console.log(error)

        }
        try {
            await api
            Axios.post('/bounty/createBounty', post)
                .then(res => {
                    console.log(res.data)
                })
        } catch (e) {
            alert(e)
        }
    }

    const getBountiesNumber = async (e) => {
        const bountiesCount = await contract.getBountiesCount();
        console.log(bountiesCount.toString());
    }

    return (
        <>
            <form onSubmit={onSubmit} className='borderBackground3'>

                <button className="nextBtn3">
                    <div >Launch</div>
                </button>



            </form><button onClick={getBountiesNumber}>
                Get Bounties Number
            </button>

        </ >
    );
};

export default Bounty;
