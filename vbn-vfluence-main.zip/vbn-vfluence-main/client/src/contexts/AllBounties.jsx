import React from 'react';
import Axios from 'axios';
import { useState } from 'react';
import api from '../api';
import { useEffect } from 'react';

const AllBounties = () => {
    const [data, setData] = useState([])
    const getBounties = async (e) => {

        try {
            await api
            Axios.get(`/bounty/all`)
                .then(res => {
                    setData(res.data)
                })
        } catch (e) {
            alert(e)
        }
    }

    useEffect(() => {
        setTimeout(() => { getBounties() }, 2000)
    }, [])

    return (
        <>
            <div >Let's See Everyone's Bounties</div>
            <div>
                {data.map(bounties =>
                    <div>
                        <p>Title:{bounties.title}</p>
                        <p>Description:{bounties.description}</p>
                        <p>Expiration Date: {bounties.expirationDate}</p>
                        <p>Creator: {bounties.creator}</p>
                        <p>Tags: {bounties.tags}</p>
                    </div>
                )}
            </div>
        </>
    );
};

export default AllBounties;