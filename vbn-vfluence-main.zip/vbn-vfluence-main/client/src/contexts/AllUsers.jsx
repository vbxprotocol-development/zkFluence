import Axios from 'axios';
import React, { createContext, useState, useEffect } from 'react';
import api from '../api';
const Context = createContext(null);

const AllUsers = ({ children }) => {
    const [users, setUsers] = useState(null);

    useEffect(() => {
        const fetchUser = async () => {
            await api
            Axios.get('/allUsers', { withCredentials: true })
                .then((res) => {
                    const usersData = res && res.data;
                    setUsers(usersData);

                })
                .catch((err) => {
                    console.log(err);
                });
        };
        fetchUser();
    }, []);

    return <Context.Provider value={users}>{children}</Context.Provider>;
};

AllUsers.Context = Context;

export default AllUsers;
