import React from 'react';
import Axios from 'axios';
import { useState } from 'react';
import api from '../api';

const YourBounty = ({ user }) => {
    const [data, setData] = useState([])
    const onSubmit = async (e) => {
        e.preventDefault()
        try {
            await api
            Axios.get(`/bounty/yourBounty/${user.firstName}`)
                .then(res => {
                    setData(res.data)
                })
        } catch (e) {
            alert(e)
        }
    }


    return (
        <>
            <button onClick={onSubmit}>Get Your Bounties</button>
            <div>
                {data.map(bounties =>
                    <div>
                        <p>Title:{bounties.title}</p>
                        <p>Description:{bounties.description}</p>
                        <p>Expiration Date: {bounties.expirationDate}</p>
                        <p>Creator: {bounties.creator}</p>
                        <p>Tags: {bounties.tags}</p>
                    </div>
                )}
            </div>
        </>
    );
};

export default YourBounty;