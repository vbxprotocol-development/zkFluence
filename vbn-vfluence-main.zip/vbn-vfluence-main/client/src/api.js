import axios from 'axios';

const baseURL =
  process.env.NODE_ENV === 'production'
    ? 'http://localhost:4000/'
    : 'https://vfluence-alpha-theta.vercel.app/';

const headers =
  process.env.NODE_ENV === 'production'
    ? {}
    : { 'Access-Control-Allow-Origin': 'http://localhost:3000' };

// Set config defaults
const instance = axios.create({
  timeout: 1000,
  headers: headers,

});

export default instance;
