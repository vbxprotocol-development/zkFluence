import React from 'react';
import Axios from 'axios';
import { useState } from 'react';
import api from '../api';

//This is used to retrieve bounties based on tags!

const Tags = ({ bountyData }) => {
    const [data, setData] = useState([])
    const [tagers, setTagers] = useState()
    const onSubmit = async (e) => {
        e.preventDefault()
        try {
            await api
            Axios.get(`/bounty/${tagers}`)
                .then(res => {
                    setData(res.data)
                    console.log(res.data)
                })
        } catch (e) {
            alert(e)
        }
    }
    const handleChange = event => {

        var selectedSkills = Array.from(event.target.selectedOptions, (item) => item.value)

        setTagers(selectedSkills);
    };

    return (
        <>
            <button onClick={onSubmit}>Get Your Bounties by Tags</button>
            <form>
                <select multiple={true} value={tagers} onChange={handleChange}>


                    <option value="Fashion">Fashion </option>

                    <option value="Home Improvement">Home Improvement </option>

                    <option value="Rap">Rap </option>

                    <option value="Comedy">Comedy </option>

                    <option value="News">News </option>

                    <option value="World Events">World Events </option>

                </select>
            </form>
            <div>
                {data.map(bounties =>
                    <div>
                        <p>Title:{bounties.title}</p>
                        <p>Description:{bounties.description}</p>
                        <p>Expiration Date: {bounties.expirationDate}</p>
                        <p>Creator: {bounties.creator}</p>
                        <p>Tags: {bounties.tags}</p>
                    </div>
                )}
            </div>




        </>
    );
};

export default Tags;