import React from 'react';
import './ChatApp.css'
import moment from 'moment'
import FlipMove from "react-flip-move"

class Message extends React.Component {
  render() {
    // Was the message sent by the current user. If so, add a css class
    const fromMe = this.props.fromMe ? 'from-me' : 'notme';

    return (
      <FlipMove>
      <div className={`message ${fromMe}`}>

        <div className='userNameSection'>
          {fromMe == 'notme' ? <img src={this.props.profilePic}  className="profilePic"/> : null}
        <div className='username'>
          { fromMe == "from-me" ? 'You' : this.props.username }</div> <div className='currentTime'>{this.props.timeStamp}</div>
        </div>
        <div className='message-body'>
          { this.props.message }
        </div>
      </div></FlipMove>
    );
  }
}

Message.defaultProps = {
  message: '',
  username: '',
  timeStamp: moment().format('dddd h:mm A'),
  fromMe: false
};

export default Message;