import React from 'react';
import Message from './Message';
import './ChatApp.css'
import Scroll from 'react-scroll'


var Element = Scroll.Element
class Messages extends React.Component {
  componentDidUpdate() {
    // There is a new message in the state, scroll to bottom of list
    const objDiv = document.getElementById('messageList');
    objDiv.scrollTop = objDiv.scrollHeight;
    
  }

  render() {
    
    // Loop through all the messages in the state and create a Message component
    const messages = this.props.messages.map((message, i) => {
        return (
          <Message
            key={i}
            username={message.username}
            message={message.message}
            fromMe={message.fromMe}
            timeStamp={message.timeStamp}
            profilePic={message.profilePic} />
        );
      });

    return (
      <div className='messages' >
        <Element style={{overflowY:'scroll'}} smooth={true} id='messageList' >
        { messages }
        </Element>
      </div>
    );
  }
}

Messages.defaultProps = {
  messages: []
};

export default Messages;