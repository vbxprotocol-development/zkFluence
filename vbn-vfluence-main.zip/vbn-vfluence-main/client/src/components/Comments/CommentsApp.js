import React from 'react';
import io from 'socket.io-client';
import Messages from './Messages';
import ChatInput from './CommentInput';
import './ChatApp.css';
import moment from 'moment'
class ChatApp extends React.Component {
    
  socket = {};
  constructor(props) {
    super(props);
    this.state = { messages: [] };
    this.sendHandler = this.sendHandler.bind(this);
    
    // Connect to the server
    this.socket = io('https://vfluence-alpha-theta.vercel.app/', { query: `username=${this.props.username}` }).connect();
    
    this.socket.on('server:message', message => {
      this.addMessage(message);
    });

    
  }

  sendHandler(message) {
    const messageObject = {
      username: this.props.username,
      message,
      timeStamp: moment().format('dddd h:mm A'),
      bountyId: this.props.id,
      profilePic: this.props.profilePic
    };

    // Emit the message to the server
    this.socket.emit('client:message', messageObject);
    
    messageObject.fromMe = true;
    this.addMessage(messageObject);
  }

  addMessage(message) {
    // Append the message to the component state
    const messages = this.state.messages;
    messages.push(message);

    this.setState({ messages });
  }

  render() {
    return (
      <div className="container">
        
        <Messages messages={this.state.messages}/>
        <ChatInput onSend={this.sendHandler} />
      </div>
    );
  }

}
ChatApp.defaultProps = {
  username: 'Anonymous'
};

export default ChatApp;