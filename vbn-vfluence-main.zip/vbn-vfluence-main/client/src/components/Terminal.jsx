import React from 'react';
import { StyledTerminal } from './style';
import TerminalTitleBar from './TerminalTitleBar';

const Terminal = () => {
  return (
    <StyledTerminal>
      <TerminalTitleBar />
      <div className="content">
        <pre>
          Sample set up to Test FrontEnd & BackEnd Functionality
        </pre>
        <pre>Using the MERN Stack, OAuth 2.0 and Passport.js </pre>
        <br />
      </div>
    </StyledTerminal>
  );
};

export default Terminal;
