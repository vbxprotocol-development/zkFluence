import React, { useEffect, useState } from 'react'
import './navbar.css'
import { Link } from 'react-router-dom';
import vibranium from '../assets/images/vibranium.png'
import searchIcon from '../assets/images/searchIcon.svg'
import mobileMenu from '../assets/images/mobileMenuDrop.svg'
import UserProvider from '../contexts/UserProvider';
import { useContext } from 'react';
import moment from 'moment';
import api from '../api'
import Axios from 'axios';
import { useWindowWidth } from './functions/useWindowWidth'

const NavBar = () => {
    const user = useContext(UserProvider.Context)

    const [contentLink, setContentLink] = useState(null)
    const [isOpen, setIsOpen] = useState(false)
    const windowWidth = useWindowWidth()
    const activity = {
        last_activity: moment().format()
    }
    const updateActivity = async () => {
        try {
            await api
            Axios.patch(`/${user._id}/userActivity`, activity)
                .then(res => {
                    console.log(res)
                })
        } catch (e) {
            alert(e)
        }
    };

    const [activeItem, setActiveItem] = useState(null);

    const handleItemClick = (itemName) => {
        setActiveItem(itemName);
    };

    const handleMenu = () => {
        setIsOpen(!isOpen)
    }



    return (
        <div className='nav'>
            <li className='mainNavButtons'>
                <ul>
                    <Link
                        to='/home'
                        className={`by ${activeItem === 'home' ? 'active' : ''}`}
                        onClick={() => handleItemClick('home')}
                    >
                        <img src={vibranium} />
                    </Link>
                </ul>
                {windowWidth < 600
                    ?
                    isOpen
                        ?
                        null
                        :
                        <ul>
                            <img src={mobileMenu} onClick={handleMenu} />
                        </ul>
                    :
                    null
                }

                {windowWidth < 600
                    ?
                    isOpen
                        ?
                        <div className='mobileNavOverlay' onClick={handleMenu}>
                            <div className='mobileNavItems'>
                                <ul>
                                    <Link
                                        to='/home'
                                        className='link'
                                    >
                                        Home
                                    </Link>
                                </ul>
                                <ul>
                                    <Link
                                        to='/myLinks'
                                        className={`link ${activeItem === 'myLinks' ? 'active' : ''}`}
                                        onClick={() => handleItemClick('myLinks')}
                                    >
                                        My Links
                                    </Link>
                                </ul>
                                <ul>
                                    <Link
                                        to='/wallet'
                                        className={`link ${activeItem === 'wallet' ? 'active' : ''}`}
                                        onClick={() => handleItemClick('wallet')}
                                    >
                                        Wallet
                                    </Link>
                                </ul>
                                <ul>
                                    <Link
                                        to='/profile'
                                        className={`link ${activeItem === 'profile' ? 'active' : ''}`}
                                        onClick={() => handleItemClick('profile')}
                                    >
                                        Profile
                                    </Link>
                                </ul>
                            </div>
                        </div>
                        :
                        null
                    :
                    <div className='navigationItems'>

                        <ul>
                            <Link
                                to='/home'
                                className='link'
                            >
                                Home
                            </Link>
                        </ul>
                        <ul>
                            <Link
                                to='/myLinks'
                                className={`link ${activeItem === 'myLinks' ? 'active' : ''}`}
                                onClick={() => handleItemClick('myLinks')}
                            >
                                My Links
                            </Link>
                        </ul>
                        <ul>
                            <Link
                                to='/wallet'
                                className={`link ${activeItem === 'wallet' ? 'active' : ''}`}
                                onClick={() => handleItemClick('wallet')}
                            >
                                Wallet
                            </Link>
                        </ul>
                        <ul>
                            <Link
                                to='/profile'
                                className={`link ${activeItem === 'profile' ? 'active' : ''}`}
                                onClick={() => handleItemClick('profile')}
                            >
                                Profile
                            </Link>
                        </ul>
                    </div>}


                <form>
                    <img src={searchIcon} className='searchIcon' />
                    <input
                        type='text'
                        placeholder='Bounty Search'
                        className='bountySearch'
                    />
                </form>
            </li>

        </div>
    );
}

export default NavBar