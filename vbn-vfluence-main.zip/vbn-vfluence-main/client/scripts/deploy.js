const { ethers } = require("hardhat");
const contractAbi = require("../src/artifacts/contracts/vbnBounty.sol/BountyContract.json");
const { artifacts } = require("hardhat");
//npx hardhat
//npx hardhat run scripts/deploy.js --network localhost

async function main() {
  
  const provider = new ethers.providers.JsonRpcProvider();
  const signer = provider.getSigner();


  
  // Get the ContractFactory and Signer objects
  const MyContract = await ethers.getContractFactory("BountyContract", contractAbi, signer);

  // Deploy the contract
  const myContract = await MyContract.deploy();

  // Wait for the contract to be deployed
  await myContract.deployed();

  console.log("MyContract deployed to:", myContract.address);
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
