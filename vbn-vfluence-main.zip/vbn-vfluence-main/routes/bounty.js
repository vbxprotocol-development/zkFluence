const express = require('express');
const bountyRoutes = express.Router();
const { ensureAuth } = require("../middleware/auth");
const {getBounty, getBountyByTags, getBountyByCreator, createBounty, getTargetedBounty, getBountyById, validateUrls, linkScraper} = require('../controllers/bounties')
const upload = require("../middleware/multer");
const bounty = require('../models/bounty');
const link = require('../models/link');

//Get all Bounties
bountyRoutes.get('/all', getBounty)

//Get a bounty by it's ID
bountyRoutes.get('/ID/:_id', getBountyById)

// Get a bounty based on a tag
bountyRoutes.get('/:tags', getBountyByTags)

// Get a bounty by Creator name
bountyRoutes.get('/yourBounty/:creator', getBountyByCreator);

// Get a bounty that is targetted to you
bountyRoutes.get('/targetted/:vFluencer', getTargetedBounty);


//Body Parsing
bountyRoutes.use(express.json({limit: '50mb'}));
bountyRoutes.use(express.urlencoded({limit: "50mb", extended: true, parameterLimit:50000}));


// Create a Bounty Route
bountyRoutes.post('/createBounty', upload.single("file"), createBounty);
bountyRoutes.post('/addLink', validateUrls, linkScraper) 

// bountyRoutes.put('/bounty/:id', updateBountyCounterById);
module.exports = bountyRoutes;