const express = require('express');
const linkRoutes = express.Router();
const { ensureAuth } = require("../middleware/auth");
const {generateLink, getLinkByCode, getLinkByCreator, getLinkByBountyId, getLinkById, getTotalClicksPerDay, getTotalClicksBasedOnBounty, getClicksBasedOnLinkID, getRecentActivity, getTodayAndYesterdayClicks, calculatePayout, calculateTotalPayouts} = require("../controllers/links");
const link = require('../models/link');

//Finds a link based on the bountyID that has been stored in it.
linkRoutes.get("/bountyID/:bountyid", getLinkByBountyId)

//Finds a link by it's ID and returns all of its data.
linkRoutes.get("/linkID/:id", getLinkById)

//Finds a link by the promoter who created the link.
linkRoutes.get("/promoter/:creator", getLinkByCreator);

//Finds a link by its urlCode and redirects to the appropriate content while adding a count.
linkRoutes.get("/:code", getLinkByCode)
linkRoutes.get("/payout/:code", calculatePayout)
linkRoutes.get("/totalPayouts/:creator", calculateTotalPayouts)


linkRoutes.get("/clicks/:userId/:timeFrame", getTotalClicksPerDay)
linkRoutes.get('/clicksBounty/:id', getTotalClicksBasedOnBounty)
linkRoutes.get('/clicks/:id', getClicksBasedOnLinkID)

linkRoutes.get('/recent-activities/:bountyID', getRecentActivity)

linkRoutes.get('/clicks-summary/:creator', getTodayAndYesterdayClicks)
//Body Parsing
linkRoutes.use(express.json({limit: '50mb'}));
linkRoutes.use(express.urlencoded({limit: "50mb", extended: true, parameterLimit:50000}));
// linkRoutes.put('/bounty/:id', updateBountyCounterById);
linkRoutes.post( "/", generateLink );

module.exports = linkRoutes;