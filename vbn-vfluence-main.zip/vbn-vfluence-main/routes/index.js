const express = require('express');
const { getAllUsers, updateActivity, updateBio } = require('../controllers/user');
const router = express.Router();
const { ensureAuth } = require("../middleware/auth");


// @desc    User
// @route   GET /user
router.get('/user', ensureAuth);

//Get all Users using VFluence
router.get('/allUsers', getAllUsers)

//Body Parsing
router.use(express.json({limit: '50mb'}));
router.use(express.urlencoded({limit: "50mb", extended: true, parameterLimit:50000}));



// Log the User's Activity via Timestamps
router.patch('/:id/userActivity', updateActivity);


//Create a Bio or update a user Bio
router.patch('/:id/bio', updateBio);
module.exports = router;

//Ignore this but leaving here for future/emergency use
// router.patch('/:id/online', async (req, res) => {
//    const {id: _id} = req.params
//    const activity = req.body.online
   
   
//    const updatedActivity =  await User.updateOne({_id},{online: activity})
//    res.json(updatedActivity)
// });