#VInfluence

-Install all dependencies using npm install
-Fill out .env file using .env.example located in config folder.
-Run server using npm start
-cd into client folder and install all dependecies using npm install
-start frontend using npm start
-navigate to localhost:3000 and sign in.