// Imports
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const dotenv = require('dotenv');
const morgan = require('morgan');
const passport = require('passport');
const session = require('express-session');
const MongoStore = require('connect-mongo')(session);
const connectDB = require('./config/db');
const path = require('path');

const http = require('http');
const io = require('socket.io');

// Config
dotenv.config({ path: './config/.env' });
require('./config/passport')(passport);

// Environment Varibles
const PORT = process.env.PORT || 4000;

// Connect to DB
connectDB();

// Start Server
const app = express();

// Static File Declaration
app.use(express.static(path.join(__dirname, 'client/build')));

// CORS Middleware
app.use(cors());

// Logging Middleware
app.use(morgan('dev'));

// Sessions Middleware
app.use(
  session({
    secret: 'keyboard cat',
    resave: false,
    saveUninitialized: false,
    store: new MongoStore({ mongooseConnection: mongoose.connection }),
   
  }),
);

// Passport Middleware
app.use(passport.initialize());
app.use(passport.session());

// Routes
app.use('/', require('./routes/index'));
app.use('/auth', require('./routes/auth'));
app.use('/bounty', require('./routes/bounty'))
app.use('/link', require('./routes/links'))

// Production Mode
if (process.env.NODE_ENV === 'production') {
  app.use(express.static(path.join(__dirname, 'client/build')));
  app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, './client/build/index.html'), err => {
      if (err) {
        res.status(500).send(err);
      }
    });
  });
  
}


// Server
const server = app.listen(PORT, console.log(`Server running on port ${PORT}`));

//Comments Section
const socketIo = io(server);
socketIo.on('connection', socket => {
  const username = socket.handshake.query.username;
  // console.log(`${username} connected`);
  socket.on('client:message', data => {
    // console.log(`${data.username}: ${data.message} ${data.bountyId}`);
    socket.join(data.bountyId)
    socket.to(data.bountyId).emit("server:message", data)
  });
  socket.on('disconnect', () => {
    console.log(`${username} disconnected`);
  });
});

//TODO: There is some logic that can be implemented to have persistent messages using sessionID without having to hit the DB. Will need to try and implement that to see if itll work.
//As of right now, there are "rooms" that are created based on the bountyID that is passed in from the client side.