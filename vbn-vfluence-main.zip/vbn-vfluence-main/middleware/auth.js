module.exports = {
    ensureAuth: function (req, res, next) {
      if (req.isAuthenticated()) {
        return res.send(req.user);
      } else {
        res
        .status(403)
        .send({ message: 'You must be logged in to perform this action.' });
    }
    }
    
}