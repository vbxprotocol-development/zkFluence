const mongoose = require('mongoose');

const bountySchema = new mongoose.Schema({
    title:{
        type: String,
        
    },
    description: {
        type: String,
        
    },
    image:{
        type: String,
        
    },
    cloudinaryId:{
        type: String,
        
    },
    creator: { 
        type: String,
        
    },
    tags: {
        type:[String],
        
    },
    bounty:{
        type: String,
       
    },
    vFluencer:{
        type: [String],
        
    },
    target:{
        type: String,
        
    },
    createdAt: {
        type: Date,
        default: new Date(),
    },
    expirationDate:{
        type: Date,
        
    },
    originalUrl:{
        type: String
    }, 
    counter:{
        type:Number
    },
    dates: [{
        date: Date,
        clicks: Number
    }],
    
})

module.exports = mongoose.model('BountyMessage', bountySchema);