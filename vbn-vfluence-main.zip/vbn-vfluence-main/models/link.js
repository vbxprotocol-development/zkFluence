const mongoose = require('mongoose');

const linkSchema = new mongoose.Schema({
    title:{
        type: String,
    },
    description: {
        type: String,
    },
    author: { 
        type: String,
    },
    image: {
        type: String
    },
    creator:{
        type: String,
    },
    creatorImg:{
        type: String,
    },
    creatorDisplayName:{
        type:String
    },
    createdAt: {
        type: Date,
        default: new Date(),
    },
    url:{
        type: String
    },
    urlCode:{
        type: String
    },
    shortUrl:{
        type: String
    },
    baseUrl:{
        type: String,
    },
    updatedAt: { 
        type: Date,
        default: Date.now
    },
    counter:{
        type: Number,
        default: 0
    },
    bountyId:{
        type: String
    },
    dates: [{
        date: Date,
        clicks: Number
    }],
    totalClicks:{
        type: Number
    },
    target:{
        type: Number
    },
    bounty:{
        type: Number
    },
    expirationDate:{
        type: String
    },
    payout: {
        type: Number,
        default: 0
    },
    disabled: {
        type: Boolean,
        default: false
    }
    
})

module.exports = mongoose.model('Link', linkSchema);